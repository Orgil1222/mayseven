<?php

/**
 * Beauly Theme functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

/**
 *---------------------------------------------------------------------------------------
 * Define constants
 *---------------------------------------------------------------------------------------
 */
define('BEAULY_THEME_NAME', 'Beauly');
define('BEAULY_THEME_SLUG', 'beauly');

define('BEAULY_THEME_VERSION', '1.0.0');

define('BEAULY_THEME_DIR', get_template_directory());
define('BEAULY_THEME_URL', get_template_directory_uri());
define('BEAULY_STYLESHEET_URL', get_stylesheet_uri());

define('BEAULY_INC_DIR', BEAULY_THEME_DIR . '/inc');
define('BEAULY_INC_URL', BEAULY_THEME_URL . '/inc');

define('BEAULY_COMMON_DIR', BEAULY_THEME_DIR . '/inc/common');
define('BEAULY_COMMON_URL', BEAULY_THEME_URL . '/inc/common');

define('BEAULY_CUSTOMIZER_DIR', BEAULY_INC_DIR . '/customizer/');

define('BEAULY_TEMPLATE_PARTS', BEAULY_THEME_DIR . '/template-parts/');

define('BEAULY_ASSETS_DIR', BEAULY_THEME_DIR . '/assets');
define('BEAULY_ASSETS_URL', BEAULY_THEME_URL . '/assets');

define('BEAULY_ASSETS_CSS_DIR', BEAULY_THEME_DIR . '/assets/css/');
define('BEAULY_ASSETS_CSS_URL', BEAULY_THEME_URL . '/assets/css/');

define('BEAULY_ASSETS_JS_DIR', BEAULY_THEME_DIR . '/assets/js/');
define('BEAULY_ASSETS_JS_URL', BEAULY_THEME_URL . '/assets/js/');

define('BEAULY_ASSETS_IMAGES_DIR', BEAULY_THEME_DIR . '/assets/img');
define('BEAULY_ASSETS_IMAGES_URL', BEAULY_THEME_URL . '/assets/img');

/**
 * ---------------------------------------------------------------------------------------
 * Template Hooks
 * ---------------------------------------------------------------------------------------
 */
require_once BEAULY_INC_DIR . '/template-hooks.php';

/**
 * ---------------------------------------------------------------------------------------
 * Template Helpers
 * ---------------------------------------------------------------------------------------
 */
require_once BEAULY_INC_DIR . '/template-helpers.php';

/**
 * ---------------------------------------------------------------------------------------
 * TGM Include
 * ---------------------------------------------------------------------------------------
 */
require_once BEAULY_INC_DIR . '/lib/class-tgm-plugin-activation.php';
require_once BEAULY_INC_DIR . '/lib/tgm-config.php';

/**
 * ---------------------------------------------------------------------------------------
 * Theme Customizer
 * ---------------------------------------------------------------------------------------
 */
require_once BEAULY_INC_DIR . '/lib/class-kirki-customizer.php';
require_once BEAULY_CUSTOMIZER_DIR . 'customizer-config.php';

/**
 * ---------------------------------------------------------------------------------------
 * Include Files
 * ---------------------------------------------------------------------------------------
 */
require_once BEAULY_INC_DIR . '/template-functions.php';

require_once BEAULY_INC_DIR . '/lib/class-navwalker.php';

if (defined('JETPACK__VERSION')) {
  require_once BEAULY_INC_DIR . '/jetpack.php';
}
