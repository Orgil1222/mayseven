<?php

/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

get_header();
?>
<section class="full-width tj-error__area error-404 not-found padding">
	<div class="container">
		<div class="row">
			<div class="col-xxl-8 offset-xxl-2 col-xl-8 offset-xl-2 col-lg-10 offset-lg-1">
				<?php
				$beauly_error_title = get_theme_mod('beauly_error_title', __('404', 'beauly'));
				$beauly_error_desc = get_theme_mod('beauly_error_desc', __('Oops! The page you are looking for does not exist. It might have been moved or deleted.', 'beauly'));
				$beauly_error_link_text = get_theme_mod('beauly_error_link_text', __('Back To Home', 'beauly'));
				?>
				<div class="tj-error__wrap text-center">
					<div class="tj-error__content">
						<h2 class="tj-error__title"><?php print esc_html($beauly_error_title); ?></h2>
						<p><?php print esc_html($beauly_error_desc); ?></p>
						<a href="<?php print esc_url(home_url('/')); ?>" class="tj-primary-btn"><?php print esc_html($beauly_error_link_text); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><!-- .error-404 -->

<?php
get_footer();
