/***************************************************
==================== JS INDEX ======================
****************************************************

=> PreLoader Js
=> Header Sticky Js
=> Header Middle Logo
=> Mobile Menu Js
=> Mobile Sidemenu
=> Search Js
=> Data CSS Js
=> Nice Select Js
=> Datetimepicker Js
=> Odometer
=> Side menu
=> Post Gallery
=> Property Gallery
=> Sponsor Carousel
=> Project Carousel
=> Testimonial Carousel
=> Apartment Carousel
=> Wow Js
=> Cart Quantity Js
=> Show Login Toggle Js
=> Show Coupon Toggle Js
=> Create An Account Toggle Js
=> Shipping Box Toggle Js
=> Parallax Js
=> InHover Active Js
=> scrollTop init

****************************************************/

(function ($) {
	"use strict";

	var windowOn = $(window);
	////////////////////////////////////////////////////
	// PreLoader Js
	windowOn.on("load", function () {
		$("#loading").fadeOut(500);
	});
	if ($("#loading").length > 0) {
		$(".closeLoader").each(function () {
			$(this).on("click", function (e) {
				e.preventDefault();
				$("#loading").fadeOut(500);
			});
		});
	}

	////////////////////////////////////////////////////
	// Header Sticky Js
	var minWidth = window.matchMedia("(min-width: 992px)");
	if ($(".header").hasClass("sticky-active")) {
		menuSticky(minWidth);
	} else {
		windowOn.on("scroll", function () {
			var scroll = $(window).scrollTop();
			if (scroll < 100) {
				$(".isSticky").removeClass("header__sticky");
			} else {
				$(".isSticky").addClass("header__sticky");
			}
		});
	}

	////////////////////////////////////////////////////
	// Header Middle Logo

	if ($(".move_logo_wrap").length > 0 && minWidth) {
		// Function to dynamically move .header-logo to the middle of top-level li elements
		function moveLogoToMiddle() {
			var container = document.querySelector(".move_logo_wrap");
			var mainMenu = container.querySelector(".mobile-menu-items");
			var siteLogo = container.querySelector(".header-logo");
			var listItems = Array.from(mainMenu.querySelectorAll("li"));

			// Filter out child li elements
			var topLevelListItems = listItems.filter(function (item) {
				return item.parentElement === mainMenu.querySelector("ul");
			});

			var middleIndex = Math.floor(topLevelListItems.length / 2);

			if (topLevelListItems.length > 0) {
				// Calculate the middle index

				// Insert the siteLogo in the middle of top-level list items
				topLevelListItems[middleIndex].insertAdjacentElement(
					"beforebegin",
					siteLogo
				);
			}
		}

		// windowOn.on("load resize", function () {
		if (minWidth) {
			// Call the function when the document is fully loaded
			window.addEventListener("load", moveLogoToMiddle);
		}
	}

	////////////////////////////////////////////////////
	// Mobile Menu Js
	$(".mobile-menu-items").meanmenu({
		meanMenuContainer: ".side-menu-wrap",
		meanScreenWidth: "991",
		meanMenuCloseSize: "30px",
		meanRemoveAttrs: true,
		meanExpand: ['<i class="fal fa-plus"></i>'],
	});

	// Mobile Sidemenu
	$(".mobile-side-menu-toggle").on("click", function () {
		$(".mobile-side-menu, .mobile-side-menu-overlay").toggleClass("is-open");
	});

	$(".mobile-side-menu-close, .mobile-side-menu-overlay").on(
		"click",
		function () {
			$(".mobile-side-menu, .mobile-side-menu-overlay").removeClass("is-open");
		}
	);

	////////////////////////////////////////////////////
	// Search Js
	$(".search-toggle").on("click", function () {
		$(".search__area").addClass("opened");
	});
	$(".search-close-btn").on("click", function () {
		$(".search__area").removeClass("opened");
	});

	////////////////////////////////////////////////////
	// Data CSS Js
	$("[data-background]").each(function () {
		$(this).css(
			"background-image",
			"url( " + $(this).attr("data-background") + "  )"
		);
	});

	$("[data-width]").each(function () {
		$(this).css("width", $(this).attr("data-width"));
	});

	$("[data-bg-color]").each(function () {
		$(this).css("background-color", $(this).attr("data-bg-color"));
	});

	////////////////////////////////////////////////////
	// Nice Select Js
	$("select").niceSelect();

	////////////////////////////////////////////////////
	//  Datetimepicker Js
	$(".date-picker").datetimepicker({
		timepicker: false,
		format: "d/m/Y",
	});
	$(".time-picker").datetimepicker({
		datepicker: false,
		format: "H:i",
		step: 5,
	});

	////////////////////////////////////////////////////
	// Odometer
	$(".odometer").waypoint(
		function () {
			var odo = $(".odometer");
			odo.each(function () {
				var countNumber = $(this).attr("data-count");
				$(this).html(countNumber);
			});
		},
		{
			offset: "80%",
			triggerOnce: true,
		}
	);

	// Side menu
	$(".side-menu-icon").on("click", function () {
		$(".side-menu-wrapper, .side-menu-overlay").toggleClass("is-open");
	});

	$(".side-menu-close, .side-menu-overlay").on("click", function () {
		$(".side-menu-wrapper, .side-menu-overlay").removeClass("is-open");
	});

	///////////////////////////////////////////////////
	// Post Gallery
	var postGallery = new Swiper(".tj-post__gallery", {
		spaceBetween: 0,
		loop: true,
		autoplay: {
			delay: 5000,
		},
		// navigation
		navigation: {
			nextEl: ".tj-gallery-button__next",
			prevEl: ".tj-gallery-button__prev",
		},
	});

	////////////////////////////////////////////////////
	// 13. Masonary Js
	$(".grid").imagesLoaded(function () {
		/* ======= ISOTOP Active ======= */
		$(".project-filter-items").imagesLoaded(function () {
			// Add isotope click function
			$(".project-filter li").on("click", function () {
				$(".project-filter li").removeClass("active");
				$(this).addClass("active");
				var selector = $(this).attr("data-filter");
				$(".project-filter-items").isotope({
					filter: selector,
					animationOptions: {
						duration: 750,
						easing: "linear",
						queue: false,
					},
				});
				return false;
			});

			$(".filters-select").on("change", function () {
				// get filter value from option value
				var filterValue = this.value;
				// use filterFn if matches value
				$(".project-filter-items").isotope({
					filter: filterValue,
					animationOptions: {
						duration: 750,
						easing: "linear",
						queue: false,
					},
				});
				return false;
			});

			$(".project-filter-items").isotope({
				itemSelector: ".single-item",
				layoutMode: "masonry",
			});
		});
	});

	/* magnificPopup img view */
	$(".popup-image").magnificPopup({
		type: "image",
		gallery: {
			enabled: true,
		},
	});

	/* magnificPopup video view */
	$(".popup-video").magnificPopup({
		type: "iframe",
	});

	////////////////////////////////////////////////////
	// Wow Js
	$(window).on("load", function () {
		var wow = new WOW({
			boxClass: "wow", // default
			animateClass: "animated", // default
			offset: 0, // default
			mobile: true, // default
			live: true, // default
		});
		wow.init();
	});

	////////////////////////////////////////////////////
	// Cart Quantity Js
	$(".cart-minus").click(function () {
		var $input = $(this).parent().find("input");
		var count = parseInt($input.val()) - 1;
		count = count < 1 ? 1 : count;
		$input.val(count);
		$input.change();
		return false;
	});
	$(".cart-plus").click(function () {
		var $input = $(this).parent().find("input");
		$input.val(parseInt($input.val()) + 1);
		$input.change();
		return false;
	});

	////////////////////////////////////////////////////
	// Show Login Toggle Js
	$("#showlogin").on("click", function () {
		$("#checkout-login").slideToggle(900);
	});

	////////////////////////////////////////////////////
	// Show Coupon Toggle Js
	$("#showcoupon").on("click", function () {
		$("#checkout_coupon").slideToggle(900);
	});

	////////////////////////////////////////////////////
	// Create An Account Toggle Js
	$("#cbox").on("click", function () {
		$("#cbox_info").slideToggle(900);
	});

	////////////////////////////////////////////////////
	// Shipping Box Toggle Js
	$("#ship-box").on("click", function () {
		$("#ship-box-info").slideToggle(1000);
	});

	////////////////////////////////////////////////////
	// Parallax Js
	if ($(".scene").length > 0) {
		$(".scene").parallax({
			scalarX: 10.0,
			scalarY: 15.0,
		});
	}

	////////////////////////////////////////////////////
	// InHover Active Js
	$(".hover__active").on("mouseenter", function () {
		$(this)
			.addClass("active")
			.parent()
			.siblings()
			.find(".hover__active")
			.removeClass("active");
	});

	////////////////////////////////////////////////////
	// scrollTop init
	var beaulyScrollTop = document.querySelector(".beauly-scroll-top");
	if (beaulyScrollTop != null) {
		var scrollProgressPatch = document.querySelector(".beauly-scroll-top path");
		var pathLength = scrollProgressPatch.getTotalLength();
		var offset = 50;
		scrollProgressPatch.style.transition =
			scrollProgressPatch.style.WebkitTransition = "none";
		scrollProgressPatch.style.strokeDasharray = pathLength + " " + pathLength;
		scrollProgressPatch.style.strokeDashoffset = pathLength;
		scrollProgressPatch.getBoundingClientRect();
		scrollProgressPatch.style.transition =
			scrollProgressPatch.style.WebkitTransition =
				"stroke-dashoffset 10ms linear";
		window.addEventListener("scroll", function (event) {
			var scroll =
				document.body.scrollTop || document.documentElement.scrollTop;
			var height =
				document.documentElement.scrollHeight -
				document.documentElement.clientHeight;
			var progress = pathLength - (scroll * pathLength) / height;
			scrollProgressPatch.style.strokeDashoffset = progress;
			var scrollElementPos =
				document.body.scrollTop || document.documentElement.scrollTop;
			if (scrollElementPos >= offset) {
				beaulyScrollTop.classList.add("progress-done");
			} else {
				beaulyScrollTop.classList.remove("progress-done");
			}
		});
		beaulyScrollTop.addEventListener("click", function (e) {
			e.preventDefault();
			window.scroll({
				top: 0,
				left: 0,
				behavior: "smooth",
			});
		});
	} // !end: ScrollTop
})(jQuery);
