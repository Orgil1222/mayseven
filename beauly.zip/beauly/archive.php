<?php

/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

get_header();

$blog_column = is_active_sidebar('blog-sidebar') ? 8 : 10;
?>

<div class="full-width tj-posts__area blog-standard-wrapper padding bg-dark-deep" id="content">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-<?php print esc_attr($blog_column); ?> ">
				<!-- post container -->
				<div class="tj-post__container blog__standard">
					<?php
					if (have_posts()) : ?>

						<?php
						/* Start the Loop */
						while (have_posts()) : the_post(); ?>
							<?php
							/*
							* Include the Post-Type-specific template for the content.
							*/
							get_template_part('template-parts/content', get_post_format()); ?>
						<?php
						endwhile;

						// pagination
						global $wp_query;
						$pages = $wp_query->max_num_pages;
						if ($pages > 1) {
						?>
							<div class="tj__pagination">
								<?php beauly_pagination('<i class="far fa-arrow-left"></i>', '<i class="far fa-arrow-right"></i>', '', ['class' => '']); ?>
							</div>
					<?php
						};

					else :
						get_template_part('template-parts/content', 'none');
					endif;
					?>
				</div>
				<!-- !post container -->
			</div>

			<?php if (is_active_sidebar('blog-sidebar')) : ?>
				<!-- sidebar -->
				<div class="col-lg-4">
					<aside class="tj-main__sidebar sidebar-wrapper">
						<?php get_sidebar(); ?>
					</aside>
				</div>
				<!--!sidebar -->
			<?php endif; ?>
		</div>
	</div>
</div>

<?php
get_footer();
