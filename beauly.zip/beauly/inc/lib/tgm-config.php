<?php

/**
 * Beauly TGM_Config
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

class TGM_Config {

  public function __construct() {
    add_action('tgmpa_register', array($this, 'register_required_plugins'));
  }
  public function register_required_plugins() {
    $plugins = [
      // Bundled
      [
        'name'               => esc_html__('TJ Beauly Core', 'beauly'),
        'slug'               => 'tj-beauly-core',
        'required'           => true,
        'source'             => esc_url('https://themejunction.net/plugins/tj-beauly-core.zip'),
        'external_url'       =>  esc_url('https://themejunction.net/plugins/tj-beauly-core.zip'),
      ],
      [
        'name'               => esc_html__('Advanced Custom Fields Pro', 'beauly'),
        'slug'               => 'advanced-custom-fields-pro',
        'required'           => true,
        'source'             => esc_url('https://themejunction.net/plugins/advanced-custom-fields-pro.zip'),
        'external_url' => esc_url('https://themejunction.net/plugins/advanced-custom-fields-pro.zip'),
      ],

      // Repository
      [
        'name'     => esc_html__('Kirki', 'beauly'),
        'slug'     => 'kirki',
        'required' => true,
      ],
      [
        'name'     => esc_html__('Advanced Custom Fields: Font Awesome Field', 'beauly'),
        'slug'     => 'advanced-custom-fields-font-awesome',
        'required' => true,
      ],
      [
        'name'     => esc_html__('Elementor', 'beauly'),
        'slug'     => 'elementor',
        'required' => true,
      ],
      [
        'name'     => esc_html__('Breadcrumb NavXT', 'beauly'),
        'slug'     => 'breadcrumb-navxt',
        'required' => true,
      ],
      [
        'name'     => esc_html__('Contact Form 7', 'beauly'),
        'slug'     => 'contact-form-7',
        'required' => true,
      ],
      [
        'name'     => esc_html__('Mailchimp For WP', 'beauly'),
        'slug'     => 'mailchimp-for-wp',
        'required' => false,
      ],
      [
        'name'     => esc_html__('One Click Demo Import', 'beauly'),
        'slug'     => 'one-click-demo-import',
        'required' => false,
      ],
      [
        'name'     => esc_html__('Smash Balloon Social Photo Feed', 'beauly'),
        'slug'     => 'instagram-feed',
        'required' => false,
      ],
      [
        'name'     => esc_html__('Classic Editor', 'beauly'),
        'slug'     => 'classic-editor',
        'required' => false,
      ],
      [
        'name'     => esc_html__('Classic Widgets', 'beauly'),
        'slug'     => 'classic-widgets',
        'required' => false,
      ],
    ];

    $config = [
      'id'           => 'beauly',            // Unique ID for hashing notices for multiple instances of TGMPA.
      'default_path' => '',              // Default absolute path to bundled plugins.
      'menu'         => 'install-required-plugins', // Menu slug.
      'has_notices'  => true,                    // Show admin notices or not.
      'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
      'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
      'is_automatic' => false,                    // Automatically activate plugins after installation or not.
      'message'      => '',                      // Message to output right before the plugins table.
    ];

    tgmpa($plugins, $config);
  }
}
new TGM_Config;
