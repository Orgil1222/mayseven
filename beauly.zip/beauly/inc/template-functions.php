<?php

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */


/**
 * ---------------------------------------------------------------------------------------
 * Get all tags
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_get_tag')) {
	function beauly_get_tag() {
		$html = '';
		if (has_tag()) {
			$html .= '<div class="tj-tag">';
			$html .= '<h4 class="tag__title">' . esc_html__('Tags : ', 'beauly') . '</h4><div class="tagcloud">';
			$html .= get_the_tag_list('', ' ', '');
			$html .= '</div></div>';
		}
		return $html;
	}
}

/**
 * ---------------------------------------------------------------------------------------
 * Get all category
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_get_category')) {
	function beauly_get_category() {

		$categories = get_the_category(get_the_ID());
		$x = 0;
		foreach ($categories as $category) {

			if ($x == 2) {
				break;
			}
			$x++;
			print '<a class="post__category" href="' . get_category_link($category->term_id) . '">' . $category->cat_name . '</a>';
		}
	}
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Image Alt Text
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_img_alt_text')) {
	function beauly_img_alt_text($img_er_id = null) {
		$image_id = $img_er_id;
		$image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', false);
		$image_title = get_the_title($image_id);

		if (!empty($image_id)) {
			if ($image_alt) {
				$alt_text = get_post_meta($image_id, '_wp_attachment_image_alt', false);
			} else {
				$alt_text = $image_title;
			}
		} else {
			$alt_text = esc_html__('Image Alt Text', 'beauly');
		}

		return $alt_text;
	}
}

/**
 * ---------------------------------------------------------------------------------------
 * Services Sidebar Function
 * ---------------------------------------------------------------------------------------
 */
function beauly_service_sidebar() {
	if (is_active_sidebar('services-sidebar')) {

		dynamic_sidebar('services-sidebar');
	}
}
add_action('beauly_service_sidebar', 'beauly_service_sidebar', 20);

/**
 * ---------------------------------------------------------------------------------------
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 * ---------------------------------------------------------------------------------------
 */
function beauly_pingback_header() {
	if (is_singular() && pings_open()) {
		printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
	}
}
add_action('wp_head', 'beauly_pingback_header');


/** ---------------------------------------------------------------
 * Get All Types Post
 *---------------------------------------------------------------*/
if (!function_exists('beauly_get_all_types_post')) {
	function beauly_get_all_types_post($post_type) {

		$posts_args = get_posts(array(
			'post_type'      => $post_type,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		));

		$posts = [];

		if (!empty($posts_args) && !is_wp_error($posts_args)) {
			foreach ($posts_args as $post) {
				$posts[$post->ID] = $post->post_title;
			}
		}

		return $posts;
	}
}
