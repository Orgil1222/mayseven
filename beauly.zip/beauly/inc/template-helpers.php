<?php

/**
 * Functions which enhance the theme by Custom Functions
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */


/**
 * ---------------------------------------------------------------------------------------
 * Beauly Before Content
 * ---------------------------------------------------------------------------------------
 */
// Preloader
add_action('beauly_before_main_content', 'beauly_preloader');
function beauly_preloader() {
  $beaulyPreloader = get_theme_mod('show_preloader', false);
  $loaderCancelText = get_theme_mod('loader_cancel_text', esc_html__('Cancel Preloader', 'beauly'));


  if (!empty($beaulyPreloader)) :
?>
    <!-- preloader -->
    <div id="loading">
      <div id="loading-center">
        <div id="loading-center-absolute">
          <div class="object" id="object_four"></div>
          <div class="object" id="object_three"></div>
          <div class="object" id="object_two"></div>
          <div class="object" id="object_one"></div>
        </div>
        <?php if (!empty($loaderCancelText)) : ?>
          <button class="closeLoader tj-primary-btn"><span><?php echo esc_html($loaderCancelText); ?></span></button>
        <?php endif; ?>
      </div>
    </div>
    <!-- end: Preloader -->
  <?php
  endif;
}

// Back to Top
add_action('beauly_before_main_content', 'beauly_back_to_top');
function beauly_back_to_top() {

  $beaulyBackToTop = get_theme_mod('beauly_backtotop', false);

  if (!empty($beaulyBackToTop)) :
  ?>
    <!-- ./ Start scrollUp -->
    <div class="beauly-scroll-top">
      <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="
                        transition: stroke-dashoffset 10ms linear 0s;
                        stroke-dasharray: 307.919px, 307.919px;
                        stroke-dashoffset: 71.1186px;
                    "></path>
      </svg>
      <div class="beauly-scroll-top-icon">
        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" data-icon="mdi:arrow-up" class="iconify iconify--mdi">
          <path fill="currentColor" d="M13 20h-2V8l-5.5 5.5l-1.42-1.42L12 4.16l7.92 7.92l-1.42 1.42L13 8v12Z"></path>
        </svg>
      </div>
    </div>
    <!-- ./ End scrollUp -->
  <?php
  endif;
}

// Hamburger Menu
add_action('beauly_before_main_content', 'beauly_hamburger_menu');
function beauly_hamburger_menu() {
  // contact info
  $contactPhone = get_theme_mod('contact_phone_number', esc_html__('+000-723-123-21', 'beauly'));
  $contactEmail = get_theme_mod('contact_email', esc_html__('beaulycontact@gmail.com', 'beauly'));
  $contactLocation = get_theme_mod('contact_location', esc_html__('Valentin, Street Road 24, New York', 'beauly'));

  // mobile menu
  $mobileSearch = get_theme_mod('beauly_mobile_search', true);
  $mobileDescription = get_theme_mod('beauly_mobile_description', beauly_kses('Quisque dignissim enim diam, eget pulvinar ex viverra id. Nulla a lobortis lectus, id volutpat magna. Morbi consequat porttitor fermentum. Nulla vestibulum tincidunt viverra. Vestibulum accumsan molestie lorem, non laoreet massa. Duis at dui sem.'));
  $mobileContactTitle = get_theme_mod('beauly_mobile_contact_title', esc_html__('Contact Us', 'beauly'));
  $mobileContactPhone = get_theme_mod('beauly_mobile_contact_phone', true);
  $mobileContactEmail = get_theme_mod('beauly_mobile_contact_email', true);
  $mobileContactLocation = get_theme_mod('beauly_mobile_contact_location', true);
  $mobileSocials = get_theme_mod('beauly_mobile_socials', true);

  ?>
  <div class="mobile-side-menu">
    <div class="side-menu-content">
      <div class="side-menu-head">
        <div class="mobile_logo">
          <?php beauly_header_logo(); ?>
        </div>
        <button class="mobile-side-menu-close"><i class="fa-light fa-times"></i></button>
      </div>

      <?php if (!empty($mobileSearch)) : ?>
        <div class="side-menu-search">
          <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="search" autocomplete="off" name="s" value="<?php echo esc_attr(get_search_query()) ?>" placeholder="<?php echo esc_attr('Search...'); ?>">
            <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </div>
      <?php endif; ?>

      <div class="side-menu-wrap"></div>

      <?php if (!empty($mobileDescription)) : ?>
        <p>
          <?php echo beauly_kses($mobileDescription); ?>
        </p>
      <?php endif; ?>

      <?php if (!empty($mobileContactTitle)) : ?>
        <h3 class="list-header"><?php echo esc_html($mobileContactTitle); ?></h3>
      <?php endif; ?>

      <ul class="side-menu-list">
        <?php if (!empty($contactLocation && $mobileContactLocation)) : ?>
          <li>
            <i class="fas fa-map-marker-alt"></i>
            <p><?php echo esc_html($contactLocation); ?></p>
          </li>
        <?php endif;
        if (!empty($contactPhone && $mobileContactPhone)) : ?>
          <li>
            <i class="fas fa-phone"></i>
            <a href="tel:<?php echo esc_attr($contactPhone); ?>"><?php echo esc_html($contactPhone); ?></a>
          </li>
        <?php endif;
        if (!empty($contactEmail && $mobileContactEmail)) : ?>
          <li>
            <i class="fas fa-envelope-open-text"></i>
            <a href="mailto:<?php echo esc_attr($contactEmail); ?>"><?php echo esc_html($contactEmail); ?></a>
          </li>
        <?php endif; ?>
      </ul>

      <?php if (!empty($mobileSocials)) : ?>
        <div class="side-menu-social">
          <?php beauly_header_socials(); ?>
        </div>
      <?php endif; ?>

    </div>
  </div>
  <!-- /.mobile-side-menu -->
  <div class="mobile-side-menu-overlay"></div>
  <?php
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Search Filter
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_search_filter_form')) {
  function beauly_search_filter_form($form) {

    $form = sprintf(
      '<div class="tj-widget__search"><form class="search-form" action="%s" method="get">
       <input class="form-control" type="search" id="search" value="%s" name="s" placeholder="%s">
       <button class="search-btn" type="submit"> <i class="fa-light fa-magnifying-glass"></i> </button>
    </form></div>',
      esc_url(home_url('/')),
      esc_attr(get_search_query()),
      esc_html__('Search', 'beauly')
    );

    return $form;
  }
  add_filter('get_search_form', 'beauly_search_filter_form');
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Breadcrumb
 * ---------------------------------------------------------------------------------------
 */
add_action('beauly_breadcrumb', 'beauly_breadcrumb_func');
function beauly_breadcrumb_func() {
  global $post;

  // id
  $_id = get_the_ID();

  $breadcrumb_class = '';
  $breadcrumb_show = 1;

  $show_breadcrumb = get_theme_mod('show_breadcrumb', true);

  $error_breadcrumb = get_theme_mod('error_show_breadcrumb', true);
  $beauly_error_title = get_theme_mod('beauly_error_title', __('404', 'beauly'));

  // page breadcrumb title
  $page_breadcrumb_title = function_exists('get_field') ? get_field('page_breadcrumb_title', $_id) : '';

  if (!empty($show_breadcrumb)) :
    // title
    if (is_front_page() && is_home()) {
      $title = get_theme_mod('blog_breadcrumb_title', __('Blog', 'beauly'));
      $breadcrumb_class = 'home_front_page';
    } elseif (is_front_page()) {
      $title = get_theme_mod('blog_breadcrumb_title', __('Blog', 'beauly'));
      $breadcrumb_show = 0;
    } elseif (is_home()) {
      $title = get_theme_mod('blog_breadcrumb_title', __('Blog', 'beauly'));
      $breadcrumb_class = 'home_blog_page';
    } elseif (is_single() && 'post' == get_post_type()) {
      if (!empty(get_theme_mod('blog_details_breadcrumb_title'))) {
        $title = get_theme_mod('blog_details_breadcrumb_title', __('Blog Details', 'beauly'));
      } else {
        $title =  get_the_title();
      }
    } elseif (is_single() && 'product' == get_post_type()) {
      $title = get_theme_mod('breadcrumb_product_details', __('Shop', 'beauly'));
    } elseif (is_search()) {
      $title = esc_html__('Search Results for : ', 'beauly') . get_search_query();
    } elseif (is_404()) {
      $title = $beauly_error_title ? $beauly_error_title : esc_html__('404', 'beauly');
      $breadcrumb_show = $error_breadcrumb ? 1 : 0;
    } elseif (function_exists('is_woocommerce') && is_woocommerce()) {
      $title = get_theme_mod('breadcrumb_shop', __('Shop', 'beauly'));
    } elseif (is_archive() && 'apartments' == get_post_type()) {
      if (!empty(get_theme_mod('breadcrumb_apartments_title'))) {
        $title = get_theme_mod('breadcrumb_apartments_title', __('Apartments', 'beauly'));
      } else {
        $title =  get_the_archive_title();;
      }
    } elseif (is_single() && 'apartments' == get_post_type()) {
      if (!empty($page_breadcrumb_title)) {
        $title = $page_breadcrumb_title;
      } else {
        $title =  get_the_title();
      }
    } elseif (is_archive() && 'teams' == get_post_type()) {
      if (!empty(get_theme_mod('breadcrumb_teams_title'))) {
        $title = get_theme_mod('breadcrumb_teams_title', __('Team Members', 'beauly'));
      } else {
        $title =  get_the_archive_title();;
      }
    } elseif (is_single() && 'teams' == get_post_type()) {
      if (!empty($page_breadcrumb_title)) {
        $title = $page_breadcrumb_title;
      } else {
        $title =  get_the_title();
      }
    } elseif (is_archive()) {
      $title = get_the_archive_title();
    } else {
      $title = !empty($page_breadcrumb_title) ? $page_breadcrumb_title : get_the_title();
    }


    if (is_single() && 'product' == get_post_type()) {
      $_id = $post->ID;
    } elseif (function_exists("is_shop") and is_shop()) {
      $_id = wc_get_page_id('shop');
    } elseif (is_home() && get_option('page_for_posts')) {
      $_id = get_option('page_for_posts');
    }

    // hide page breadcrumb
    $is_breadcrumb = function_exists('get_field') ? get_field('hide_page_breadcrumb', $_id) : false;

    if ((false == $is_breadcrumb) && $breadcrumb_show == 1) {
      // IMAGES
      $breadcrumb_page_bg_image = function_exists('get_field') ? get_field('breadcrumb_page_bg_image', $_id) : '';

      // customizer
      $customizer_bg_img = get_theme_mod('breadcrumb_bg_img');
      $bg_color = get_theme_mod('breadcrumb_bg_color', '#2b2c30');

      $blog_breadcrumb_img = get_theme_mod('blog_breadcrumb_img');
      $blog_details_breadcrumb_img = get_theme_mod('blog_details_breadcrumb_img');

      $breadcrumb_apartments_img = get_theme_mod('breadcrumb_apartments_img');
      $breadcrumb_teams_img = get_theme_mod('breadcrumb_teams_img');

      $error_breadcrumb_img = get_theme_mod('beauly_error_breadcrumb_img');

      // image
      if (is_front_page() && is_home()) {
        $bg_img = $blog_breadcrumb_img ? $blog_breadcrumb_img : $customizer_bg_img;
      } elseif (is_front_page()) {
        $bg_img = $blog_breadcrumb_img ? $blog_breadcrumb_img : $customizer_bg_img;
      } elseif (is_home()) {
        $bg_img = $blog_breadcrumb_img ? $blog_breadcrumb_img : $customizer_bg_img;
      } elseif (is_single() && 'post' == get_post_type()) {
        $bg_img = $blog_details_breadcrumb_img ? $blog_details_breadcrumb_img : (has_post_thumbnail() ? get_the_post_thumbnail_url() : $customizer_bg_img);
      } elseif (is_404()) {
        $bg_img = $error_breadcrumb_img ? $error_breadcrumb_img : $customizer_bg_img;
      } elseif (is_archive() && 'apartments' == get_post_type()) {
        $bg_img = $breadcrumb_apartments_img ? $breadcrumb_apartments_img : $customizer_bg_img;
      } elseif (is_single() && 'apartments' == get_post_type()) {
        if (!empty($breadcrumb_page_bg_image['url'])) {
          $bg_img =  $breadcrumb_page_bg_image['url'] ?? $customizer_bg_img;
        } else {
          $bg_img = has_post_thumbnail() ? get_the_post_thumbnail_url() : $customizer_bg_img;
        }
      } elseif (is_archive() && 'teams' == get_post_type()) {
        $bg_img = $breadcrumb_teams_img ? $breadcrumb_teams_img : $customizer_bg_img;
      } elseif (is_single() && 'teams' == get_post_type()) {
        if (!empty($breadcrumb_page_bg_image['url'])) {
          $bg_img =  $breadcrumb_page_bg_image['url'] ?? $customizer_bg_img;
        } else {
          $bg_img = has_post_thumbnail() ? get_the_post_thumbnail_url() : $customizer_bg_img;
        }
      } elseif (is_single()) {
        $bg_img = has_post_thumbnail() ? get_the_post_thumbnail_url() : $customizer_bg_img;
      } else {
        $bg_img = !empty($breadcrumb_page_bg_image['url']) ? $breadcrumb_page_bg_image['url'] : $customizer_bg_img;
      }

      // NAVIGATION
      $breadcrumb_navigation_switch = get_theme_mod('breadcrumb_navigation_switch', true);
      $show_page_breadcrumb_navigation = function_exists('get_field') ? get_field('show_page_breadcrumb_navigation', $_id) : '';

      // navigation
      if (is_single() && 'apartments' == get_post_type()) {
        $is_navigation = !empty($show_page_breadcrumb_navigation) ? $show_page_breadcrumb_navigation : false;
      } else if (is_single() && 'teams' == get_post_type()) {
        $is_navigation = !empty($show_page_breadcrumb_navigation) ? $show_page_breadcrumb_navigation : false;
      } else {
        $is_navigation = !empty($show_page_breadcrumb_navigation) ? $show_page_breadcrumb_navigation : $breadcrumb_navigation_switch;
      }
  ?>

      <section class="page-header bg-dark-light <?php echo esc_attr($breadcrumb_class); ?>" <?php if (!empty($bg_color)) : ?> data-bg-color="<?php echo esc_attr($bg_color); ?>" <?php endif;
                                                                                                                                                                                if (!empty($bg_img)) : ?> data-background="<?php echo esc_url($bg_img); ?>" <?php endif; ?>>
        <div class="container">
          <div class="col-lg-12">
            <div class="page-header-content text-center">
              <h1 class="title wow fadeInUp" data-wow-delay=".3s"><?php echo beauly_kses($title); ?></h1>

              <?php if (!empty($is_navigation)) : ?>
                <div class="breadcrumb__link wow fadeInUp" data-wow-delay=".5s">
                  <?php if (function_exists('bcn_display')) {
                    bcn_display();
                  } ?>
                </div>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </section>
    <?php
    }
  endif;
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Header Style
 * ---------------------------------------------------------------------------------------
 */
add_action('beauly_header_style', 'beauly_check_header', 10);
function beauly_check_header() {

  $beauly_select_headers = get_theme_mod('select_headers', 'default');
  $elementor_header_style    = get_theme_mod('elementor_header_style', 0);
  $default_header_style   = get_theme_mod('default_header_style', 'header-style-1');

  // header style from page settings
  $enable_header_settings = function_exists('get_field') ? get_field('enable_header_settings') : false;
  $select_page_headers = function_exists('get_field') ? get_field('select_page_headers') : 'default-headers';

  $page_default_header_style = function_exists('get_field') ? get_field('page_default_header_style') : NULL;
  $page_elementor_header_style = function_exists('get_field') ? get_field('page_elementor_header_style') : NULL;


  // from page headers
  if (!empty($enable_header_settings)) {
    if ('default-headers' == $select_page_headers) {
      // page header style
      if ($page_default_header_style == 'header-style-1') {
        get_template_part('template-parts/header/header-1');
      } elseif ($page_default_header_style == 'header-style-2') {
        get_template_part('template-parts/header/header-2');
      } elseif ($page_default_header_style == 'header-style-3') {
        get_template_part('template-parts/header/header-3');
      } elseif ($page_default_header_style == 'header-style-4') {
        get_template_part('template-parts/header/header-4');
      }
    } else {
      if (class_exists('\\Elementor\\Plugin')) {
        if ($page_elementor_header_style) {
          TJ_HF_Builder::render_template($page_elementor_header_style->ID);
        } else {
          printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('No Headers Found! — set custom header {Appearance -> TJ Header Builder}', 'beauly'));
        }
      } else {
        printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('Beauly requires Elementor to be installed and activated.', 'beauly'));
      }
    }
  } else {
    // from cutomizer headers
    if ('default' == $beauly_select_headers) {
      /** default header style **/
      if ($default_header_style == 'header-style-2') {
        get_template_part('template-parts/header/header-2');
      } elseif ($default_header_style == 'header-style-3') {
        get_template_part('template-parts/header/header-3');
      } elseif ($default_header_style == 'header-style-4') {
        get_template_part('template-parts/header/header-4');
      } else {
        get_template_part('template-parts/header/header-1');
      }
    } else {
      if (class_exists('\\Elementor\\Plugin')) {
        if ($elementor_header_style > 0) {
          TJ_HF_Builder::render_template($elementor_header_style);
        } else {
          printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('No Headers Found! — set custom header {Appearance -> TJ Header Builder}', 'beauly'));
        }
      } else {
        printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('Beauly requires Elementor to be installed and activated.', 'beauly'));
      }
    }
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Footer Style
 * ---------------------------------------------------------------------------------------
 */
add_action('beauly_footer_style', 'beauly_check_footer', 10);
function beauly_check_footer() {

  $beauly_select_footers = get_theme_mod('select_footers', 'default');
  $elementor_footer_style    = get_theme_mod('elementor_footer_style', 0);
  $default_footer_style   = get_theme_mod('default_footer_style', 'footer-style-1');

  // footer style from page settings
  $enable_footer_settings = function_exists('get_field') ? get_field('enable_footer_settings') : false;
  $select_page_footers = function_exists('get_field') ? get_field('select_page_footers') : 'default-footers';

  $page_default_footer_style = function_exists('get_field') ? get_field('page_default_footer_style') : NULL;
  $page_elementor_footer_style = function_exists('get_field') ? get_field('page_elementor_footer_style') : NULL;


  // from Page Footers
  if (!empty($enable_footer_settings)) {
    if ('default-footers' == $select_page_footers) {
      // page footer style
      if ($page_default_footer_style == 'footer-style-1') {
        get_template_part('template-parts/footer/footer-1');
      } elseif ($page_default_footer_style == 'footer-style-2') {
        get_template_part('template-parts/footer/footer-2');
      } elseif ($page_default_footer_style == 'footer-style-3') {
        get_template_part('template-parts/footer/footer-3');
      }
    } else {

      if (class_exists('\\Elementor\\Plugin')) {
        if ($page_elementor_footer_style) {
          TJ_HF_Builder::render_template($page_elementor_footer_style->ID);
        } else {
          printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('No Footers Found! — set custom header {Appearance -> TJ Footer Builder}', 'beauly'));
        }
      } else {
        printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('Beauly requires Elementor to be installed and activated.', 'beauly'));
      }
    }
  } else {
    // from cutomizer Footers
    if ('default' == $beauly_select_footers) {
      /** default footer style **/
      if ($default_footer_style == 'footer-style-2') {
        get_template_part('template-parts/footer/footer-2');
      } elseif ($default_footer_style == 'footer-style-3') {
        get_template_part('template-parts/footer/footer-3');
      } else {
        get_template_part('template-parts/footer/footer-1');
      }
    } else {

      if (class_exists('\\Elementor\\Plugin')) {
        if ($elementor_footer_style > 0) {
          TJ_HF_Builder::render_template($elementor_footer_style);
        } else {
          printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('No Footers Found! — set custom header {Appearance -> TJ Footer Builder}', 'beauly'));
        }
      } else {
        printf('<div class="alert alert-warning" role="alert">%s</div>', esc_html__('Beauly requires Elementor to be installed and activated.', 'beauly'));
      }
    }
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Header Logo
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_header_logo')) {
  function beauly_header_logo() { ?>
    <?php
    $beauly_logo       = BEAULY_ASSETS_IMAGES_URL . '/logo/logo-primary.png';

    $beauly_site_logo      = get_theme_mod('primary_logo', $beauly_logo);
    ?>

    <a class="primary-logo" href="<?php echo esc_url(home_url('/')); ?>">
      <img src="<?php echo esc_url($beauly_site_logo); ?>" alt="<?php echo esc_attr__('logo', 'beauly'); ?>" />
    </a>
  <?php
  }
}
if (!function_exists('beauly_header_vertical_logo')) {
  function beauly_header_vertical_logo() { ?>
    <?php
    $beauly_vertical_logo       = BEAULY_ASSETS_IMAGES_URL . '/logo/logo-vertical.png';

    $beauly_site_logo      = get_theme_mod('vertical_logo', $beauly_vertical_logo);
    ?>

    <a class="vertical-logo" href="<?php echo esc_url(home_url('/')); ?>">
      <img src="<?php echo esc_url($beauly_site_logo); ?>" alt="<?php echo esc_attr__('logo', 'beauly'); ?>" />
    </a>
  <?php
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Header Sticky Logo
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_header_sticky_logo')) {
  function beauly_header_sticky_logo() { ?>
    <?php
    $beauly_logo_black     = get_template_directory_uri() . '/assets/img/logo/logo-black.png';
    $beauly_secondary_logo = get_theme_mod('secondary_logo', $beauly_logo_black);
    ?>
    <a class="sticky-logo" href="<?php echo esc_url(home_url('/')); ?>">
      <img src="<?php echo esc_url($beauly_secondary_logo); ?>" alt="<?php echo esc_attr__('logo', 'beauly'); ?>" />
    </a>
    <?php
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Header Mobile Logo
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_mobile_logo')) {
  function beauly_mobile_logo() {
    // side info
    $beauly_mobile_logo_hide = get_theme_mod('beauly_mobile_logo_hide', false);

    $beauly_site_logo = get_theme_mod('primary_logo', get_template_directory_uri() . '/assets/img/logo/logo-white.png');

    if (!empty($beauly_mobile_logo_hide)) : ?>
      <div class="side__logo mb-25">
        <a class="sideinfo-logo" href="<?php echo esc_url(home_url('/')); ?>">
          <img src="<?php echo esc_url($beauly_site_logo); ?>" alt="<?php echo esc_attr__('logo', 'beauly'); ?>" />
        </a>
      </div>
    <?php endif;
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Header Menu
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_header_menu')) {
  function beauly_header_menu() {

    if (has_nav_menu('main-menu')) {
      wp_nav_menu([
        'theme_location' => 'main-menu',
        'menu_class'     => '',
        'menu_id'        => '',
        'container'      => '',
        'fallback_cb'    => 'Beauly_Navwalker_Class::fallback',
        'walker'         => new Beauly_Navwalker_Class,
      ]);
    } else {
      wp_nav_menu([
        'menu_class'     => '',
        'container'      => '',
      ]);
    }
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Mobile Menu
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_mobile_menu')) {
  function beauly_mobile_menu() {

    $beauly_menu = wp_nav_menu([
      'theme_location' => 'main-menu',
      'menu_class'     => '',
      'container'      => '',
      'menu_id'        => 'mobile-menu-active',
      'echo'           => false,
    ]);

    $beauly_menu = str_replace("menu-item-has-children", "menu-item-has-children has-children", $beauly_menu);
    echo wp_kses_post($beauly_menu);
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Header Footer Menu
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_footer_menu')) {
  function beauly_footer_menu() {
    if (has_nav_menu('footer-menu')) {
      wp_nav_menu([
        'theme_location' => 'footer-menu',
        'menu_class'     => '',
        'container'      => '',
        'fallback_cb'    => 'Beauly_Navwalker_Class::fallback',
        'walker'         => new Beauly_Navwalker_Class,
      ]);
    } else {
      wp_nav_menu([
        'menu_class'     => '',
        'container'      => '',
      ]);
    }
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Copyright Text
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_copyright')) {
  function beauly_copyright_text() {
    $beauly_copyright = get_theme_mod('beauly_copyright', beauly_kses('&copy; Copyright 2023 <a href="#">Beauly</a> All Rights Reserved.'));
    echo beauly_kses($beauly_copyright);
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Header Socials
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_header_socials')) {
  function beauly_header_socials() {
    $beauly_header_fb_link        = get_theme_mod('beauly_fb_link', '');
    $beauly_header_twitter_link   = get_theme_mod('beauly_twitter_link', '');
    $beauly_header_linkedin_link  = get_theme_mod('beauly_linkedin_link', '');
    $beauly_header_instagram_link = get_theme_mod('beauly_instagram_link', '');
    $beauly_header_youtube_link   = get_theme_mod('beauly_youtube_link', '');
    ?>

    <ul class="top-social-list">
      <?php if (!empty($beauly_header_fb_link)) : ?>
        <li><a href="<?php echo esc_url($beauly_header_fb_link); ?>"><span><i class="fab fa-facebook-f"></i></span></a></li>
      <?php endif; ?>

      <?php if (!empty($beauly_header_twitter_link)) : ?>
        <li><a href="<?php echo esc_url($beauly_header_twitter_link); ?>"><span><i class="fab fa-x-twitter"></i></span></a></li>
      <?php endif; ?>

      <?php if (!empty($beauly_header_instagram_link)) : ?>
        <li><a href="<?php echo esc_url($beauly_header_instagram_link); ?>"><span><i class="fab fa-instagram"></i></span></a></li>
      <?php endif; ?>

      <?php if (!empty($beauly_header_linkedin_link)) : ?>
        <li><a href="<?php echo esc_url($beauly_header_linkedin_link); ?>"><span><i class="fab fa-linkedin-in"></i></span></a></li>
      <?php endif; ?>

      <?php if (!empty($beauly_header_youtube_link)) : ?>
        <li><a href="<?php echo esc_url($beauly_header_youtube_link); ?>"><span><i class="fab fa-youtube"></i></span></a></li>
      <?php endif; ?>
    </ul>

  <?php
  }
}


/**
 * ---------------------------------------------------------------------------------------
 * Beauly Pagination
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_pagination')) {

  function _beauly_pagi_callback($pagination) {
    return $pagination;
  }

  //page navigation
  function beauly_pagination($prev, $next, $pages, $args) {
    global $wp_query, $wp_rewrite;
    $menu                                         = '';
    $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

    if ($pages == '') {
      global $wp_query;
      $pages = $wp_query->max_num_pages;

      if (!$pages) {
        $pages = 1;
      }
    }

    $pagination = [
      'base'      => add_query_arg('paged', '%#%'),
      'format'    => '',
      'total'     => $pages,
      'current'   => $current,
      'prev_text' => $prev,
      'next_text' => $next,
      'type'      => 'array',
    ];

    //rewrite permalinks
    if ($wp_rewrite->using_permalinks()) {
      $pagination['base'] = user_trailingslashit(trailingslashit(remove_query_arg('s', get_pagenum_link(1))) . 'page/%#%/', 'paged');
    }

    if (!empty($wp_query->query_vars['s'])) {
      $pagination['add_args'] = ['s' => get_query_var('s')];
    }

    $pagi = '';
    if (paginate_links($pagination) != '') {
      $paginations = paginate_links($pagination);
      $pagi .= '<ul>';
      foreach ($paginations as $key => $pg) {
        $pagi .= '<li>' . $pg . '</li>';
      }
      $pagi .= '</ul>';
    }

    echo _beauly_pagi_callback($pagi);
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * Beauly Comment
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_comment')) {
  function beauly_comment($comment, $args, $depth) {
    $GLOBAL['comment'] = $comment;
    extract($args, EXTR_SKIP);
    $args['reply_text'] = 'Reply';
    $replayClass        = 'comment-depth-' . esc_attr($depth);
  ?>
    <li class="tj__comment" id="comment-<?php comment_ID(); ?>">
      <div class="tj-comment__wrap">
        <div class="comment__avatar">
          <?php echo get_avatar($comment, 102, null, null, ['class' => []]); ?>
        </div>
        <div class="comment__text">
          <div class="avatar__name">
            <h5><?php echo get_comment_author_link(); ?></h5>
            <span><?php comment_time(get_option('date_format')); ?></span>
          </div>
          <?php comment_text(); ?>

          <div class="comment__reply">
            <?php comment_reply_link(array_merge($args, ['depth' => $depth, 'max_depth' => $args['max_depth']])); ?>
          </div>

        </div>
      </div>
  <?php
  }
}

/**
 * ---------------------------------------------------------------------------------------
 * WP kses allowed tags
 * ---------------------------------------------------------------------------------------
 */
if (!function_exists('beauly_kses')) {
  function beauly_kses($raw) {

    $allowed_tags = array(
      'a'                             => array(
        'class'  => array(),
        'href'   => array(),
        'rel'    => array(),
        'title'  => array(),
        'target' => array(),
      ),
      'abbr'                          => array(
        'title' => array(),
      ),
      'b'                             => array(),
      'blockquote'                    => array(
        'cite' => array(),
      ),
      'cite'                          => array(
        'title' => array(),
      ),
      'code'                          => array(),
      'del'                           => array(
        'datetime' => array(),
        'title'    => array(),
      ),
      'dd'                            => array(),
      'div'                           => array(
        'class' => array(),
        'title' => array(),
        'style' => array(),
      ),
      'dl'                            => array(),
      'dt'                            => array(),
      'em'                            => array(),
      'h1'                            => array(),
      'h2'                            => array(),
      'h3'                            => array(),
      'h4'                            => array(),
      'h5'                            => array(),
      'h6'                            => array(),
      'i'                             => array(
        'class' => array(),
      ),
      'img'                           => array(
        'alt'    => array(),
        'class'  => array(),
        'height' => array(),
        'src'    => array(),
        'width'  => array(),
      ),
      'li'                            => array(
        'class' => array(),
      ),
      'ol'                            => array(
        'class' => array(),
      ),
      'p'                             => array(
        'class' => array(),
      ),
      'q'                             => array(
        'cite'  => array(),
        'title' => array(),
      ),
      'span'                          => array(
        'class' => array(),
        'title' => array(),
        'style' => array(),
      ),
      'iframe'                        => array(
        'width'       => array(),
        'height'      => array(),
        'scrolling'   => array(),
        'frameborder' => array(),
        'allow'       => array(),
        'src'         => array(),
      ),
      'strike'                        => array(),
      'br'                            => array(),
      'strong'                        => array(),
      'data-wow-duration'             => array(),
      'data-wow-delay'                => array(),
      'data-wallpaper-options'        => array(),
      'data-stellar-background-ratio' => array(),
      'ul'                            => array(
        'class' => array(),
      ),
      'svg'                           => array(
        'class'           => true,
        'aria-hidden'     => true,
        'aria-labelledby' => true,
        'role'            => true,
        'xmlns'           => true,
        'width'           => true,
        'height'          => true,
        'viewbox'         => true, // <= Must be lower case!
      ),
      'g'                             => array('fill' => true),
      'title'                         => array('title' => true),
      'path'                          => array('d' => true, 'fill' => true),
    );

    if (function_exists('wp_kses')) { // WP is here
      $allowed = wp_kses($raw, $allowed_tags);
    } else {
      $allowed = $raw;
    }

    return $allowed;
  }
}
