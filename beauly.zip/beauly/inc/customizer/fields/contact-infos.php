<?php

/**
 * Customizer Contact Infos
 *
 * style for theme Contact Infos
 */

$fields[] = array(
  'type'     => 'custom',
  'settings' => 'general_custom_01',
  'label'    => FALSE,
  'section'  => 'beauly_contact_infos',
  'default'  => '<div class="customizer_label">' . esc_html__('Contact Infos', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
);
// number
$fields[] = [
  'type'            => 'text',
  'settings'        => 'contact_phone_number',
  'label'           => esc_html__('Contact Number', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('+000-723-123-21', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// email
$fields[] = [
  'type'            => 'text',
  'settings'        => 'contact_email',
  'label'           => esc_html__('Contact Email', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('beaulycontact@gmail.com', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// location
$fields[] = [
  'type'            => 'text',
  'settings'        => 'contact_location',
  'label'           => esc_html__('Location', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('Valentin, Street Road 24, New York', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];

$fields[] = array(
  'type'     => 'custom',
  'settings' => 'general_custom_02',
  'label'    => FALSE,
  'section'  => 'beauly_contact_infos',
  'default'  => '<div class="customizer_label">' . esc_html__('Socials Info', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
);
// facebook
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_fb_link',
  'label'           => esc_html__('Facebook', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('https://facebook.com/', 'beauly'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// twitter
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_twitter_link',
  'label'           => esc_html__('Twitter', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('https://twitter.com/', 'beauly'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// linkedin
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_linkedin_link',
  'label'           => esc_html__('Linkedin', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('https://linkedin.com/', 'beauly'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// instagram
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_instagram_link',
  'label'           => esc_html__('Instagram', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// youtube
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_youtube_link',
  'label'           => esc_html__('Youtube', 'beauly'),
  'section'         => 'beauly_contact_infos',
  'default'         => esc_html__('https://youtube.com/', 'beauly'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
