<?php

/**
 * Customizer Breadcrumb Settings
 *
 * style for theme breadcrumb style
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'header_custom_01',
  'label'    => FALSE,
  'section'  => 'breadcrumb_setting',
  'default'  => '<div class="customizer_label">' . esc_html__('Breadcrumb Settings', 'beauly') . '</div>',
];
// navigation info
$fields[] = [
  'type'     => 'switch',
  'settings' => 'show_breadcrumb',
  'label'    => esc_html__('Show breadcrumb?', 'beauly'),
  'section'  => 'breadcrumb_setting',
  'default'  => '1',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
// background image
$fields[] = [
  'type'        => 'image',
  'settings'    => 'breadcrumb_bg_img',
  'label'       => esc_html__('Background Image', 'beauly'),
  'section'     => 'breadcrumb_setting',
  'active_callback' => [
    [
      'setting'  => 'show_breadcrumb',
      'operator' => '==',
      'value'    => '1',
    ],
  ],
];
// background color
$fields[] = [
  'type'        => 'color',
  'settings'    => 'breadcrumb_bg_color',
  'label'       => __('Background Color', 'beauly'),
  'section'     => 'breadcrumb_setting',
  'default'     => '#2b2c30',
  'priority'    => 10,
  'active_callback' => [
    [
      'setting'  => 'show_breadcrumb',
      'operator' => '==',
      'value'    => '1',
    ],
  ],
];
// background color
$fields[] = [
  'type'        => 'color',
  'settings'    => 'breadcrumb_bg_overlay_color',
  'label'       => __('Background Overlay Color', 'beauly'),
  'section'     => 'breadcrumb_setting',
  'transport'   => 'auto',
  'choices'     => [
    'alpha' => true,
  ],
  'default'     => 'rgba(27, 28, 29, 0.5)',
  'output'      => [
    [
      'element'  => '.page-header::before',
      'property' => 'background-color',
    ],
  ],
  'active_callback' => [
    [
      'setting'  => 'show_breadcrumb',
      'operator' => '==',
      'value'    => '1',
    ],
  ],
];
// navigation switcher
$fields[] = [
  'type'     => 'switch',
  'settings' => 'breadcrumb_navigation_switch',
  'label'    => esc_html__('Breadcrumb Navigation on/off?', 'beauly'),
  'section'  => 'breadcrumb_setting',
  'default'  => '1',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'show_breadcrumb',
      'operator' => '==',
      'value'    => '1',
    ],
  ],
];
