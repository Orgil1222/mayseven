<?php

/**
 * Customizer Logos & Favicon
 *
 * style for theme logos & favicon
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'logos_custom_01',
  'label'    => FALSE,
  'section'  => 'beauly_theme_logos',
  'default'  => '<div class="customizer_label">' . esc_html__('Site Logos', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// primary logo
$fields[] = [
  'type'     => 'image',
  'settings' => 'primary_logo',
  'label'    => esc_html__('Primary Logo', 'beauly'),
  'section'  => 'beauly_theme_logos',
  'default'     => BEAULY_ASSETS_IMAGES_URL . '/logo/logo-primary.png',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// secondary logo
$fields[] = [
  'type'     => 'image',
  'settings' => 'secondary_logo',
  'label'    => esc_html__('Secondary Logo', 'beauly'),
  'section'  => 'beauly_theme_logos',
  'default'     => BEAULY_ASSETS_IMAGES_URL . '/logo/logo-secondary.png',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// vertical logo
$fields[] = [
  'type'     => 'image',
  'settings' => 'vertical_logo',
  'label'    => esc_html__('Vertical Logo', 'beauly'),
  'section'  => 'beauly_theme_logos',
  'default'     => BEAULY_ASSETS_IMAGES_URL . '/logo/logo-vertical.png',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
