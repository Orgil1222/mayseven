<?php

/**
 * Customizer Apartments Settings
 *
 * style for theme Apartments
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'apartments_custom_01',
  'label'    => FALSE,
  'section'  => 'apartments_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Apartments Archive', 'beauly') . '</div>',
];
// breadcrumb title
$fields[] = [
  'type'     => 'text',
  'settings' => 'breadcrumb_apartments_title',
  'label'    => esc_html__('Breadcrumb Title', 'beauly'),
  'section'  => 'apartments_settings',
  'default'  => esc_html__('Apartments', 'beauly'),
];
// breadcrumb Image
$fields[] = [
  'type'        => 'image',
  'settings'    => 'breadcrumb_apartments_img',
  'label'       => esc_html__('Breadcrumb Image', 'beauly'),
  'description' => esc_html__('', 'beauly'),
  'section'     => 'apartments_settings',
];
