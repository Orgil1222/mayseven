<?php

/**
 * Customizer Blog Settings
 *
 * style for theme blogs
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'blog_custom_01',
  'label'    => FALSE,
  'section'  => 'blog_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Blog Page Settings', 'beauly') . '</div>',
];
// breadcrumb title
$fields[] = [
  'type'     => 'text',
  'settings' => 'blog_breadcrumb_title',
  'label'    => esc_html__('Blog Breadcrumb Title', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => esc_html__('Blog', 'beauly'),
  'priority' => 10,
];
// blog breadcrumb image
$fields[] = [
  'type'        => 'image',
  'settings'    => 'blog_breadcrumb_img',
  'label'       => esc_html__('Blog Breadcrumb Image', 'beauly'),
  'section'     => 'blog_settings',
];
// Blog button
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_blog_btn_switch',
  'label'    => esc_html__('BTN On/Off', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => '1',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
// button text
$fields[] = [
  'type'     => 'text',
  'settings' => 'beauly_blog_btn',
  'label'    => esc_html__('Button text', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => esc_html__('Read More', 'beauly'),
  'priority' => 10,
  'active_callback' => [
    [
      'setting'  => 'beauly_blog_btn_switch',
      'operator' => '==',
      'value'    => '1',
    ],
  ],
];
// category meta
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_blog_cat',
  'label'    => esc_html__('Category Meta On/Off', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => '0',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
// author meta
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_blog_author',
  'label'    => esc_html__('Author Meta On/Off', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => '1',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
// date meta
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_blog_date',
  'label'    => esc_html__('Date Meta On/Off', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => '1',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
// comment meta
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_blog_comments',
  'label'    => esc_html__('Comments Meta On/Off', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => '1',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];

// blog details
$fields[] = [
  'type'     => 'custom',
  'settings' => 'blog_custom_02',
  'label'    => FALSE,
  'section'  => 'blog_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Blog Details Page', 'beauly') . '</div>',
];
// blog details breadcrumb title
$fields[] = [
  'type'     => 'text',
  'settings' => 'blog_details_breadcrumb_title',
  'label'    => esc_html__('Blog Details Breadcrumb Title', 'beauly'),
  'section'  => 'blog_settings',
  'priority' => 10,
];
// blog details breadcrumb image
$fields[] = [
  'type'        => 'image',
  'settings'    => 'blog_details_breadcrumb_img',
  'label'       => esc_html__('Blog Details Breadcrumb Image', 'beauly'),
  'section'     => 'blog_settings',
];
// blog social share
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_blog_social',
  'label'    => esc_html__('Blog Socials Share On/Off', 'beauly'),
  'section'  => 'blog_settings',
  'default'  => '0',
  'priority' => 10,
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
