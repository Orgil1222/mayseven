<?php

/**
 * Customizer permalink Settings
 *
 * style for theme permalink
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'permalink_custom_01',
  'label'    => FALSE,
  'section'  => 'permalink_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Permalink', 'beauly') . '</div>',
];
// apartments_slug
$fields[] = [
  'type'     => 'text',
  'settings' => 'apartments_slug',
  'label'    => esc_html__('Apartments Slug', 'beauly'),
  'section'  => 'permalink_settings',
  'default'  => esc_html__('apartments', 'beauly'),
];
// apartment_type
$fields[] = [
  'type'     => 'text',
  'settings' => 'apartment_type',
  'label'    => esc_html__('Apartment Type', 'beauly'),
  'section'  => 'permalink_settings',
  'default'  => esc_html__('apartment-type', 'beauly'),
];
// apartment_location
$fields[] = [
  'type'     => 'text',
  'settings' => 'apartment_location',
  'label'    => esc_html__('Apartment Location', 'beauly'),
  'section'  => 'permalink_settings',
  'default'  => esc_html__('apartment-location', 'beauly'),
];
// teams_slug
$fields[] = [
  'type'     => 'text',
  'settings' => 'teams_slug',
  'label'    => esc_html__('Teams Slug', 'beauly'),
  'section'  => 'permalink_settings',
  'default'  => esc_html__('teams', 'beauly'),
];
