<?php

/**
 * Customizer 404 Settings
 *
 * style for theme 404 page
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => '404_custom_01',
  'label'    => FALSE,
  'section'  => '404_page',
  'default'  => '<div class="customizer_label">' . esc_html__('404 Page Settings', 'beauly') . '</div>',
];
// error breadcrumb image
$fields[] = [
  'type'        => 'image',
  'settings'    => 'beauly_error_breadcrumb_img',
  'label'       => esc_html__('Breadcrumb Image', 'beauly'),
  'section'     => '404_page',
];
// title
$fields[] = [
  'type'     => 'text',
  'settings' => 'beauly_error_title',
  'label'    => esc_html__('Title', 'beauly'),
  'section'  => '404_page',
  'default'  => esc_html__('404', 'beauly'),
];
// description
$fields[] = [
  'type'     => 'textarea',
  'settings' => 'beauly_error_desc',
  'label'    => esc_html__('Description', 'beauly'),
  'section'  => '404_page',
  'default'  => esc_html__('Oops! The page you are looking for does not exist. It might have been moved or deleted.', 'beauly'),
];
// button link Text
$fields[] = [
  'type'     => 'text',
  'settings' => 'beauly_error_link_text',
  'label'    => esc_html__('Button Text', 'beauly'),
  'section'  => '404_page',
  'default'  => esc_html__('Back To Home', 'beauly'),
];
