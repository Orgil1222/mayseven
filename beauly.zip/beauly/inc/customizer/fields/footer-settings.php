<?php

/**
 * Customizer Footer Settings
 *
 * style for theme footer
 */

$footers = Kirki_Helper::get_posts([
  'post_type'      => 'tj-footer-builder',
  'post_status'    => 'publish',
  'posts_per_page' => -1,
  'orderby'        => 'title',
  'order'          => 'ASC',
]);

// select footers
$fields[] = [
  'type'     => 'custom',
  'settings' => 'footer_custom_01',
  'label'    => FALSE,
  'section'  => 'footer_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Select Footers', 'beauly') . '</div>',
];
$fields[] = [
  'type'     => 'select',
  'settings' => 'select_footers',
  'section'  => 'footer_settings',
  'default'  => 'default',
  'choices'  => [
    'default' => esc_html__('Default Footers', 'beauly'),
    'elementor'  => esc_html__('Elementor Footers', 'beauly'),
  ],
];

if (!empty($footers)) :
  $fields[] = [
    'type'            => 'custom',
    'settings'        => 'footer_custom_02',
    'label'           => FALSE,
    'section'         => 'footer_settings',
    'default'         => '<div class="customizer_label mt-25">' . esc_html__('Choose Elementor Style', 'beauly') . '</div>',
    'active_callback' => [
      [
        'setting'  => 'select_footers',
        'operator' => '==',
        'value'    => 'elementor',
      ],
    ],
  ];
  $fields[] = [
    'type'            => 'select',
    'settings'        => 'elementor_footer_style',
    'section'         => 'footer_settings',
    'choices'         => $footers,
    'default'         => 'footer-1',
    'active_callback' => [
      [
        'setting'  => 'select_footers',
        'operator' => '==',
        'value'    => 'elementor',
      ],
    ],
  ];
else :
  $fields[] = [
    'type'            => 'custom',
    'settings'        => 'footer_custom_02',
    'label'           => FALSE,
    'section'         => 'footer_settings',
    'default'         => '<div class="alert alert-warning" role="alert">' . esc_html__('No Footers Found! — set elementor footer {Appearance -> TJ Footer Builder}', 'beauly') . '</div>',
    'active_callback' => [
      [
        'setting'  => 'select_footers',
        'operator' => '==',
        'value'    => 'elementor',
      ],
    ],
  ];
endif;

// Select Default Footer
$fields[] = [
  'type'            => 'custom',
  'settings'        => 'footer_custom_03',
  'label'           => FALSE,
  'section'         => 'footer_settings',
  'default'         => '<div class="customizer_label mt-25">' . esc_html__('Choose Default Style', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
$fields[] = [
  'type'            => 'radio-image',
  'settings'        => 'default_footer_style',
  'label'           => FALSE,
  'section'         => 'footer_settings',
  'placeholder'     => esc_html__('Select an option...', 'beauly'),
  'priority'        => 10,
  'multiple'        => 1,
  'choices'         => [
    'footer-style-1' => BEAULY_INC_URL . '/assets/img/footer/footer-1.png',
    'footer-style-2' => BEAULY_INC_URL . '/assets/img/footer/footer-2.png',
    'footer-style-3' => BEAULY_INC_URL . '/assets/img/footer/footer-3.png',
  ],
  'default'         => 'footer-style-1',
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];

$fields[] = [
  'type'            => 'custom',
  'settings'        => 'footer_custom_04',
  'label'           => FALSE,
  'section'         => 'footer_settings',
  'default'         => '<div class="customizer_label mt-25">' . esc_html__('Footer Settings', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// Footer Column
$fields[] = [
  'type'            => 'select',
  'settings'        => 'footer_widget_column',
  'label'           => esc_html__('Widget Column', 'beauly'),
  'section'         => 'footer_settings',
  'default'         => '4',
  'placeholder'     => esc_html__('Select an option...', 'beauly'),
  'priority'        => 10,
  'multiple'        => 1,
  'choices'         => [
    '4' => esc_html__('Column 4', 'beauly'),
    '3' => esc_html__('Column 3', 'beauly'),
    '2' => esc_html__('Column 2', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// footer style 2 switcher 
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'footer_style_2_switch',
  'label'           => esc_html__('Show footer style 2 ?', 'beauly'),
  'section'         => 'footer_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// footer style 3 switcher 
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'footer_style_3_switch',
  'label'           => esc_html__('Show footer style 3 ?', 'beauly'),
  'section'         => 'footer_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];

// footer bg image
$fields[] = [
  'type'            => 'image',
  'settings'        => 'footer_bg_img',
  'label'           => esc_html__('Background Image', 'beauly'),
  'section'         => 'footer_settings',
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];

// footer bg color
$fields[] = [
  'type'            => 'color',
  'settings'        => 'footer_bg_color',
  'label'           => esc_html__('Background Color', 'beauly'),
  'description'     => esc_html__('This color will be show footer background.', 'beauly'),
  'section'         => 'footer_settings',
  'default'         => '#222326',
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];

// copyright text
$fields[] = [
  'type'            => 'textarea',
  'settings'        => 'beauly_copyright',
  'label'           => esc_html__('Copyright Text', 'beauly'),
  'section'         => 'footer_settings',
  'default'         => beauly_kses('&copy; Copyright 2023 <a href="#">Beauly</a> All Rights Reserved.'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];

// footer menu switcher
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'footer_menu_switcher',
  'label'           => esc_html__('Footer Bottom Menu', 'beauly'),
  'section'         => 'footer_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_footers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
