<?php

/**
 * Customizer Mobile Menu
 *
 * style for theme Mobile Menu
 */

$fields[] = array(
  'type'     => 'custom',
  'settings' => 'general_custom_01',
  'label'    => FALSE,
  'section'  => 'beauly_mobile_menu',
  'default'  => '<div class="customizer_label">' . esc_html__('Mobile Menu', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
);
// search switch
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'beauly_mobile_search',
  'label'           => esc_html__('Show search bar?', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// menu description
$fields[] = [
  'type'            => 'textarea',
  'settings'        => 'beauly_mobile_description',
  'label'           => esc_html__('Description', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => esc_html__('Quisque dignissim enim diam, eget pulvinar ex viverra id. Nulla a lobortis lectus, id volutpat magna. Morbi consequat porttitor fermentum. Nulla vestibulum tincidunt viverra. Vestibulum accumsan molestie lorem, non laoreet massa. Duis at dui sem.', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// contact title
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_mobile_contact_title',
  'label'           => esc_html__('Contact Title', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => esc_html__('Contact Us', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// phone switch
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'beauly_mobile_contact_phone',
  'label'           => esc_html__('Show phone number?', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// email switch
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'beauly_mobile_contact_email',
  'label'           => esc_html__('Show email?', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
// email switch
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'beauly_mobile_contact_location',
  'label'           => esc_html__('Show location?', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];

// email switch
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'beauly_mobile_socials',
  'label'           => esc_html__('Show socials?', 'beauly'),
  'section'         => 'beauly_mobile_menu',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ]
  ],
];
