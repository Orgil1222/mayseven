<?php

/**
 * Customizer Header TopBar
 *
 * style for theme header TopBar
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'topbar_custom_01',
  'label'    => FALSE,
  'section'  => 'header_top_bar',
  'default'  => '<div class="customizer_label">' . esc_html__('Header Top Bar', 'beauly') . '</div>',
];

// Header Top Bar
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_topbar_switch',
  'label'    => esc_html__('Topbar Switcher', 'beauly'),
  'section'  => 'header_top_bar',
  'default'  => '0',
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
];
// phone
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_phone_num',
  'label'           => esc_html__('Phone Number', 'beauly'),
  'section'         => 'header_top_bar',
  'default'         => esc_html__('+(088) 234 567 899', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
  ],
];

// email
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_mail_id',
  'label'           => esc_html__('Mail ID', 'beauly'),
  'section'         => 'header_top_bar',
  'default'         => esc_html__('info@beauly.com', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
  ],
];

// email
$fields[] = [
  'type'            => 'text',
  'settings'        => 'beauly_address',
  'label'           => esc_html__('Address', 'beauly'),
  'section'         => 'header_top_bar',
  'default'         => esc_html__('Moon ave, New York, 2020 NY US', 'beauly'),
  'active_callback' => [
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
  ],
];
