<?php

/**
 * Customizer Header Settings
 *
 * style for theme headers
 */

$headers = Kirki_Helper::get_posts([
  'post_type'      => 'tj-header-builder',
  'post_status'    => 'publish',
  'posts_per_page' => -1,
  'orderby'        => 'title',
  'order'          => 'ASC',
]);

// select headers
$fields[] = [
  'type'     => 'custom',
  'settings' => 'header_setting_custom_01',
  'label'    => FALSE,
  'section'  => 'header_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Select Headers', 'beauly') . '</div>',
];
$fields[] = [
  'type'     => 'select',
  'settings' => 'select_headers',
  'section'  => 'header_settings',
  'default'  => 'default',
  'choices'  => [
    'default' => esc_html__('Default Headers', 'beauly'),
    'elementor'  => esc_html__('Elementor Headers', 'beauly'),
  ],
];
if (!empty($headers)) :
  $fields[] = [
    'type'            => 'custom',
    'settings'        => 'header_setting_custom_02',
    'label'           => FALSE,
    'section'         => 'header_settings',
    'default'         => '<div class="customizer_label mt-25">' . esc_html__('Choose Elementor Header', 'beauly') . '</div>',
    'active_callback' => [
      [
        'setting'  => 'select_headers',
        'operator' => '==',
        'value'    => 'elementor',
      ],
    ],
  ];
  $fields[] = [
    'type'            => 'select',
    'settings'        => 'elementor_header_style',
    'section'         => 'header_settings',
    'choices'         => $headers,
    'default'         => 'header-1',
    'active_callback' => [
      [
        'setting'  => 'select_headers',
        'operator' => '==',
        'value'    => 'elementor',
      ],
    ],
  ];
else :
  $fields[] = [
    'type'            => 'custom',
    'settings'        => 'header_custom_02',
    'label'           => FALSE,
    'section'         => 'header_settings',
    'default'         => '<div class="alert alert-warning" role="alert">' . esc_html__('No Headers Found! — set elementor header {Appearance -> TJ Header Builder}', 'beauly') . '</div>',
    'active_callback' => [
      [
        'setting'  => 'select_headers',
        'operator' => '==',
        'value'    => 'elementor',
      ],
    ],
  ];
endif;

$fields[] = [
  'type'            => 'custom',
  'settings'        => 'header_setting_custom_03',
  'label'           => FALSE,
  'section'         => 'header_settings',
  'default'         => '<div class="customizer_label mt-25">' . esc_html__('Choose Default Header', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// Header Default
$fields[] = [
  'type'            => 'radio-image',
  'settings'        => 'default_header_style',
  'section'         => 'header_settings',
  'priority'        => 10,
  'multiple'        => 1,
  'choices'         => [
    'header-style-1' => BEAULY_INC_URL . '/assets/img/header/header-1.png',
    'header-style-2' => BEAULY_INC_URL . '/assets/img/header/header-2.png',
    'header-style-3' => BEAULY_INC_URL . '/assets/img/header/header-3.png',
    'header-style-4' => BEAULY_INC_URL . '/assets/img/header/header-4.png',
  ],
  'default'         => 'header-style-1',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];

$fields[] = [
  'type'     => 'custom',
  'settings' => 'header_setting_custom_04',
  'label'    => FALSE,
  'section'  => 'header_settings',
  'default'  => '<div class="customizer_label mt-25">' . esc_html__('Header Settings', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// contact no switcher
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'header_sticky',
  'label'           => esc_html__('Is header sticky?', 'beauly'),
  'section'         => 'header_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// contact no switcher
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'header_absolute',
  'label'           => esc_html__('Is header absolute?', 'beauly'),
  'section'         => 'header_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// contact no switcher
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'header_right_phone',
  'label'           => esc_html__('Show contact number?', 'beauly'),
  'section'         => 'header_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => ['header-style-1', 'header-style-2'],
    ],
  ],
];
// header sidebar
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'header_right_sidebar',
  'label'           => esc_html__('Show header sidebar?', 'beauly'),
  'section'         => 'header_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => ['header-style-3'],
    ],
  ],
];

// right button
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'header_right_button',
  'label'           => esc_html__('Show button?', 'beauly'),
  'section'         => 'header_settings',
  'default'         => '0',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// right button text
$fields[] = [
  'type'            => 'text',
  'settings'        => 'header_right_button_text',
  'label'           => esc_html__('Button Text', 'beauly'),
  'section'         => 'header_settings',
  'default'         => esc_html__('Schedule a Visit', 'beauly'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'header_right_button',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
// right button link
$fields[] = [
  'type'            => 'link',
  'settings'        => 'header_right_button_link',
  'label'           => esc_html__('Button Link', 'beauly'),
  'section'         => 'header_settings',
  'default'         => esc_html__('#', 'beauly'),
  'priority'        => 10,
  'active_callback' => [
    [
      'setting'  => 'header_right_button',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
  ],
];
