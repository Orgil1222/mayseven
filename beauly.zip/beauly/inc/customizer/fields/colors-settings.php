<?php

/**
 * Customizer Colors Settings
 *
 * style for theme colors
 */

$fields[] = array(
  'type'     => 'custom',
  'settings' => 'color_custom_01',
  'label'    => FALSE,
  'section'  => 'colors_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Global Color', 'beauly') . '</div>',
);
$fields[] = array(
  'type'        => 'color',
  'settings'    => 'tj_body_color_hex',
  'section'     => 'colors_settings',
  'label'       => esc_html__('Body Color', 'beauly'),
  'description' => esc_html__('Insert your site body global text color HEX code. this color option work all over the site.', 'beauly'),
  'default'     => '#cfcfcf',
  'transport'   => 'auto',
  'output'      => [
    [
      'element'  => ':root',
      'property' => '--tj-color-text-body',
    ],
  ],
);
// primary
$fields[] = array(
  'type'        => 'color',
  'settings'    => 'tj_primary_color_hex',
  'section'     => 'colors_settings',
  'label'       => esc_html__('Primary Color', 'beauly'),
  'description' => esc_html__('Insert your site primary color HEX code. this color option work all over the site.', 'beauly'),
  'default'     => '#bd8c62',
  'transport'   => 'auto',
  'output'      => [
    [
      'element'  => ':root',
      'property' => '--tj-color-theme-primary',
    ],
  ],
);
// secondary
$fields[] = array(
  'type'        => 'color',
  'settings'    => 'tj_secondary_color_hex',
  'section'     => 'colors_settings',
  'label'       => esc_html__('Secondary Color', 'beauly'),
  'description' => esc_html__('Insert your site secondary color HEX code. this color option work all over the site.', 'beauly'),
  'default'     => '#222326',
  'transport'   => 'auto',
  'output'      => [
    [
      'element'  => ':root',
      'property' => '--tj-color-theme-bg-dark',
    ],
  ],
);

$fields[] = array(
  'type'     => 'custom',
  'settings' => 'color_custom_02',
  'label'    => FALSE,
  'section'  => 'colors_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('All Headings Color', 'beauly') . '</div>',
);
$fields[] = array(
  'type'        => 'color',
  'settings'    => 'tj_heading_primary_color_hex',
  'section'     => 'colors_settings',
  'label'       => esc_html__('Primary Color', 'beauly'),
  'description' => esc_html__('Insert your site all headings primary color HEX code.', 'beauly'),
  'default'     => '#ffffff',
  'transport'   => 'auto',
  'output'      => [
    [
      'element'  => ':root',
      'property' => '--tj-color-heading-primary',
    ],
  ],
);
