<?php

/**
 * Customizer General Settings
 *
 * style for theme general settings
 */

$fields[] = [
    'type'     => 'custom',
    'settings' => 'general_custom_01',
    'label'    => FALSE,
    'section'  => 'general_settings',
    'default'  => '<div class="customizer_label">' . esc_html__('Global Site Settings', 'beauly') . '</div>',
];
// backToTop
$fields[] = [
    'type'     => 'switch',
    'settings' => 'beauly_backtotop',
    'label'    => esc_html__('Show Back to Top', 'beauly'),
    'section'  => 'general_settings',
    'default'  => '0',
    'priority' => 10,
    'choices'  => [
        'on'  => esc_html__('Enable', 'beauly'),
        'off' => esc_html__('Disable', 'beauly'),
    ],
];

// preloader
$fields[] = [
    'type'     => 'switch',
    'settings' => 'show_preloader',
    'label'    => esc_html__('Show Preloader', 'beauly'),
    'section'  => 'general_settings',
    'default'  => '0',
    'choices'  => [
        'on'  => esc_html__('Enable', 'beauly'),
        'off' => esc_html__('Disable', 'beauly'),
    ],
];
// background color
$fields[] = array(
    'type'            => 'color',
    'settings'        => 'loader_bg_color',
    'label'           => esc_html__('Loader BG Color', 'beauly'),
    'section'         => 'general_settings',
    'default'         => '#1e1f21',
    'choices'         => [
        'alpha' => true,
    ],
    'transport'       => 'auto',
    'output'          => [
        [
            'element'  => '#loading::after',
            'property' => 'background-color',
        ],
    ],
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
// loader color
$fields[] = array(
    'type'            => 'color',
    'settings'        => 'loader_anim_color',
    'label'           => esc_html__('Loader Animation Color', 'beauly'),
    'section'         => 'general_settings',
    'default'         => '#bd8c62',
    'choices'         => [
        'alpha' => true,
    ],
    'transport'       => 'auto',
    'output'          => [
        [
            'element'  => '#loading #loading-center #loading-center-absolute .object',
            'property' => 'border-left-color',
        ],
        [
            'element'  => '#loading #loading-center #loading-center-absolute .object',
            'property' => 'border-top-color',
        ],
    ],
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
// loader cancel text
$fields[] = array(
    'type'            => 'text',
    'settings'        => 'loader_cancel_text',
    'label'           => esc_html__('Loader Cancel Btn Text', 'beauly'),
    'section'         => 'general_settings',
    'default'         => esc_html__('Cancel Preloader', 'beauly'),
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
// cancel button bg
$fields[] = array(
    'type'            => 'color',
    'settings'        => 'loader_cancel_bg_color',
    'label'           => esc_html__('Cancel Btn BG Color', 'beauly'),
    'section'         => 'general_settings',
    'default'         => '#bd8c62',
    'choices'         => [
        'alpha' => true,
    ],
    'transport'       => 'auto',
    'output'          => [
        [
            'element'  => '#loading #loading-center .closeLoader',
            'property' => 'background-color',
        ],
    ],
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
// cancel button text color
$fields[] = array(
    'type'            => 'color',
    'settings'        => 'loader_cancel_text_color',
    'label'           => esc_html__('Cancel Btn Text Color', 'beauly'),
    'section'         => 'general_settings',
    'default'         => '#ffffff',
    'choices'         => [
        'alpha' => true,
    ],
    'transport'       => 'auto',
    'output'          => [
        [
            'element'  => '#loading #loading-center .closeLoader',
            'property' => 'color',
        ],
    ],
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
// cancel button hover bg
$fields[] = array(
    'type'            => 'color',
    'settings'        => 'loader_cancel_hover_bg_color',
    'label'           => esc_html__('Cancel Btn Hover BG Color', 'beauly'),
    'section'         => 'general_settings',
    'default'         => '#bd8c62',
    'choices'         => [
        'alpha' => true,
    ],
    'transport'       => 'auto',
    'output'          => [
        [
            'element'  => '#loading #loading-center .closeLoader:hover',
            'property' => 'background-color',
        ],
    ],
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
// cancel button hover text color
$fields[] = array(
    'type'            => 'color',
    'settings'        => 'loader_cancel_hover_text_color',
    'label'           => esc_html__('Cancel Btn Hover Text Color', 'beauly'),
    'section'         => 'general_settings',
    'default'         => '#ffffff',
    'choices'         => [
        'alpha' => true,
    ],
    'transport'       => 'auto',
    'output'          => [
        [
            'element'  => '#loading #loading-center .closeLoader:hover',
            'property' => 'color',
        ],
    ],
    'active_callback' => [
        [
            'setting'  => 'show_preloader',
            'operator' => '==',
            'value'    => true,
        ],
    ],
);
