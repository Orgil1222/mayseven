<?php

/**
 * Customizer Teams Settings
 *
 * style for theme Teams
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'teams_custom_01',
  'label'    => FALSE,
  'section'  => 'teams_settings',
  'default'  => '<div class="customizer_label">' . esc_html__('Teams Breadcrumb', 'beauly') . '</div>',
];
// breadcrumb title
$fields[] = [
  'type'     => 'text',
  'settings' => 'breadcrumb_teams_title',
  'label'    => esc_html__('Breadcrumb Title', 'beauly'),
  'section'  => 'teams_settings',
  'default'  => esc_html__('Team Members', 'beauly'),
  'priority' => 10,
];
// breadcrumb Image
$fields[] = [
  'type'        => 'image',
  'settings'    => 'breadcrumb_teams_img',
  'label'       => esc_html__('Breadcrumb Image', 'beauly'),
  'description' => esc_html__('', 'beauly'),
  'section'     => 'teams_settings',
];
