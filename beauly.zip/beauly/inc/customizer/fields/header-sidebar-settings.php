<?php

/**
 * Customizer Header Sidebar Settings
 *
 * style for theme header sidebar
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'header_side_custom_01',
  'label'    => FALSE,
  'section'  => 'header_side_setting',
  'default'  => '<div class="customizer_label">' . esc_html__('Header Sidebar Settings', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => ['header-style-3'],
    ],
  ],
];
// Title
$fields[] = [
  'type'     => 'textarea',
  'settings' => 'sidebar_title',
  'label'    => esc_html__('Sidebar Title', 'beauly'),
  'section'  => 'header_side_setting',
  'default'  => esc_html__('Here is a Quick Search Through All of Our Apartments.', 'beauly'),
  'priority' => 10,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => ['header-style-3'],
    ],
  ],
];
// Show Apartment
$fields[] = [
  'type'     => 'number',
  'settings' => 'show_apartments',
  'label'    => esc_html__('Show Apartments', 'beauly'),
  'section'  => 'header_side_setting',
  'default'  => 6,
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => ['header-style-3'],
    ],
  ],
];
// Choose Apartment
$fields[] = [
  'type'     => 'select',
  'settings' => 'choose_apartments',
  'label'    => esc_html__('Choose Apartments', 'beauly'),
  'description' => esc_html__('Leave empty to show all apartment types.', 'beauly'),
  'section'  => 'header_side_setting',
  'multiple'    => get_theme_mod('show_apartments', 6),
  'choices'     => beauly_get_all_types_post('apartments'),
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => ['header-style-3'],
    ],
  ],
];
