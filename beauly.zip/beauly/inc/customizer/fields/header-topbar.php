<?php

/**
 * Customizer Header TopBar
 *
 * style for theme header TopBar
 */

$fields[] = [
  'type'     => 'custom',
  'settings' => 'topbar_custom_01',
  'label'    => FALSE,
  'section'  => 'header_top_bar',
  'default'  => '<div class="customizer_label">' . esc_html__('Header Top Bar', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];
// Header Top Bar switcher
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_topbar_switch',
  'label'    => esc_html__('Topbar Switcher', 'beauly'),
  'section'  => 'header_top_bar',
  'default'  => 'on',
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];
// mail switcher
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'topbar_email_switcher',
  'label'           => esc_html__('Show topbar email?', 'beauly'),
  'section'         => 'header_top_bar',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
  ],
];
// contact number
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'topbar_contact_no_switcher',
  'label'           => esc_html__('Show topbar contact no?', 'beauly'),
  'section'         => 'header_top_bar',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
  ],
];

// socials switcher
$fields[] = [
  'type'            => 'switch',
  'settings'        => 'topbar_socials',
  'label'           => esc_html__('Show topbar socials?', 'beauly'),
  'section'         => 'header_top_bar',
  'default'         => '1',
  'priority'        => 10,
  'choices'         => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
  ],
];

// on Mobile
$fields[] = [
  'type'     => 'custom',
  'settings' => 'topbar_custom_02',
  'label'    => FALSE,
  'section'  => 'header_top_bar',
  'default'  => '<div class="customizer_label">' . esc_html__('Header Top Bar on Mobile', 'beauly') . '</div>',
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];
// Header Top Bar on Mobile switcher
$fields[] = [
  'type'     => 'switch',
  'settings' => 'beauly_topbar_mobile_switch',
  'label'    => esc_html__('Topbar Switcher', 'beauly'),
  'section'  => 'header_top_bar',
  'default'  => 'on',
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];
// mobile topbar email
$fields[] = [
  'type'     => 'switch',
  'settings' => 'topbar_mobile_email_switcher',
  'label'    => esc_html__('Show topbar email?', 'beauly'),
  'section'  => 'header_top_bar',
  'default'  => 'on',
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'beauly_topbar_mobile_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];
// mobile topbar contact no
$fields[] = [
  'type'     => 'switch',
  'settings' => 'topbar_mobile_contact_no_switcher',
  'label'    => esc_html__('Show topbar contact no?', 'beauly'),
  'section'  => 'header_top_bar',
  'default'  => 'on',
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'beauly_topbar_mobile_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];

// Mobile social switcher
$fields[] = [
  'type'     => 'switch',
  'settings' => 'topbar_mobile_socials_switcher',
  'label'    => esc_html__('Show topbar socials?', 'beauly'),
  'section'  => 'header_top_bar',
  'default'  => 'on',
  'choices'  => [
    'on'  => esc_html__('Enable', 'beauly'),
    'off' => esc_html__('Disable', 'beauly'),
  ],
  'active_callback' => [
    [
      'setting'  => 'select_headers',
      'operator' => '==',
      'value'    => 'default',
    ],
    [
      'setting'  => 'beauly_topbar_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'beauly_topbar_mobile_switch',
      'operator' => '==',
      'value'    => true,
    ],
    [
      'setting'  => 'default_header_style',
      'operator' => 'in',
      'value'    => 'header-style-4',
    ],
  ],
];
