<?php

/**
 * Beauly Customizer Configuration
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

if (!defined('ABSPATH')) {
  exit;
}

// Do not proceed if Kirki does not exist.
if (!class_exists('Kirki')) {
  return;
}

class Beauly_Customizer {

  public static $_instance;

  public function __construct() {
    add_action('customize_register', [$this, 'beauly_customizer_sections']);
    add_filter('kirki/fields', [$this, 'beauly_customizer_setting']);
    add_action('customize_preview_init', [$this, 'beauly_customize_preview_js']);
  }

  /**
   *    ---------------------------------------------------------------------------------------
   *    Customizer Sections
   *    ---------------------------------------------------------------------------------------
   */
  public function beauly_customizer_sections($wp_customize) {
    // Customizer Panel
    $wp_customize->add_panel('beauly_customizer_panel', [
      'priority' => 10,
      'title'    => esc_html__('Beauly Customizer', 'beauly'),
    ]);

    // general settings
    $wp_customize->add_section('general_settings', [
      'title'       => esc_html__('General Settings', 'beauly'),
      'priority'    => 1,
      'description' => esc_html__('To change site general settings and google map api.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // typography settings
    $wp_customize->add_section('typo_settings', [
      'title'       => esc_html__('Typography Settings', 'beauly'),
      'priority'    => 2,
      'description' => esc_html__('Setup site typography settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // colors settings
    $wp_customize->add_section('colors_settings', [
      'title'       => esc_html__('Color Settings', 'beauly'),
      'priority'    => 3,
      'description' => esc_html__('Setup site color settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // header settings
    $wp_customize->add_section('header_settings', [
      'title'       => esc_html__('Header Settings', 'beauly'),
      'priority'    => 4,
      'description' => esc_html__('Setup site header settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // Logos
    $wp_customize->add_section('beauly_theme_logos', [
      'title'       => esc_html__('Site Logos', 'beauly'),
      'description' => esc_html__('Setup site logos.', 'beauly'),
      'priority'    => 5,
      'capability'  => 'edit_theme_options',
      'panel'       => 'beauly_customizer_panel',
    ]);

    // Header Topbar
    $wp_customize->add_section('header_top_bar', [
      'title'       => esc_html__('Header Topbar', 'beauly'),
      'priority'    => 6,
      'description' => esc_html__('Setup site header topbar settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // Header Sidebar
    $wp_customize->add_section('header_side_setting', [
      'title'       => esc_html__('Header Sidebar', 'beauly'),
      'priority'    => 7,
      'description' => esc_html__('Setup site header sidebar settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // Contact Infos
    $wp_customize->add_section('beauly_contact_infos', [
      'title'       => esc_html__('Contact Info', 'beauly'),
      'description' => esc_html__('Setup site contact infos.', 'beauly'),
      'priority'    => 8,
      'panel'       => 'beauly_customizer_panel',
    ]);

    // mobile menu
    $wp_customize->add_section('beauly_mobile_menu', [
      'title'       => esc_html__('Mobile Menu', 'beauly'),
      'description' => esc_html__('Setup site mobile menu infos.', 'beauly'),
      'priority'    => 9,
      'panel'       => 'beauly_customizer_panel',
    ]);

    // Sidebar Settings
    $wp_customize->add_section('header_side_setting', [
      'title'       => esc_html__('Sidebar Settings', 'beauly'),
      'description' => esc_html__('Setup site sidebar settings.', 'beauly'),
      'priority'    => 10,
      'panel'       => 'beauly_customizer_panel',
    ]);

    // Breadcrumb Settings
    $wp_customize->add_section('breadcrumb_setting', [
      'title'       => esc_html__('Breadcrumb Setting', 'beauly'),
      'priority'    => 11,
      'description' => esc_html__('Setup site breadcrumb settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // blog settings
    $wp_customize->add_section('blog_settings', [
      'title'       => esc_html__('Blog Settings', 'beauly'),
      'priority'    => 12,
      'description' => esc_html__('Setup blog pages settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // footer settings
    $wp_customize->add_section('footer_settings', [
      'title'       => esc_html__('Footer Settings', 'beauly'),
      'priority'    => 13,
      'description' => esc_html__('Setup site footer settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // apartments settings
    $wp_customize->add_section('apartments_settings', [
      'title'       => esc_html__('Apartments Settings', 'beauly'),
      'priority'    => 14,
      'description' => esc_html__('Setup site apartments settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // teams settings
    $wp_customize->add_section('teams_settings', [
      'title'       => esc_html__('Teams Settings', 'beauly'),
      'priority'    => 15,
      'description' => esc_html__('Setup site teams settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // permalink settings
    $wp_customize->add_section('permalink_settings', [
      'title'       => esc_html__('Permalink Settings', 'beauly'),
      'priority'    => 16,
      'description' => esc_html__('Setup site permalink settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);

    // 404 page settings
    $wp_customize->add_section('404_page', [
      'title'       => esc_html__('404 Page', 'beauly'),
      'priority'    => 17,
      'description' => esc_html__('Setup 404 page settings.', 'beauly'),
      'panel'       => 'beauly_customizer_panel',
    ]);
  }

  /**
   *    ---------------------------------------------------------------------------------------
   *    Customizer Settings Fields
   *    ---------------------------------------------------------------------------------------
   */
  public function beauly_customizer_setting($fields) {

    require BEAULY_CUSTOMIZER_DIR . 'fields/general-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/typography-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/colors-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/header-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/theme-logos.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/header-topbar.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/contact-infos.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/mobile-menu.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/header-sidebar-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/breadcrumb-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/blog-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/footer-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/apartments-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/teams-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/permalink-settings.php';
    require BEAULY_CUSTOMIZER_DIR . 'fields/404-settings.php';

    return $fields;
  }

  /**
   *    ---------------------------------------------------------------------------------------
   *    Customizer Preview JS
   *    ---------------------------------------------------------------------------------------
   */
  public function beauly_customize_preview_js() {
    wp_enqueue_script('beauly-customizer', BEAULY_INC_URL . '/assets/js/customize-preview.js', array('customize-preview'), BEAULY_THEME_VERSION, true);
  }

  public static function beauly_get_instance() {
    if (!isset(self::$_instance)) {
      self::$_instance = new Beauly_Customizer();
    }
    return self::$_instance;
  }
}
$beauly_Fields = Beauly_Customizer::beauly_get_instance();
