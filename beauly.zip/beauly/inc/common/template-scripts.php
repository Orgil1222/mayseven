<?php

/**
 * Beauly Theme Scripts
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

if (!defined('ABSPATH')) {
  exit;
}


function beauly_scripts() {
  /**
   * ---------------------------------------------------------------------------------------
   * Enqueue All CSS Files
   * ---------------------------------------------------------------------------------------
   */
  wp_enqueue_style('beauly-google-fonts', beauly_google_fonts_url(), '', null);

  if (is_rtl()) {
    wp_enqueue_style('bootstrap-rtl', BEAULY_ASSETS_CSS_URL . 'bootstrap.rtl.min.css', []);
  } else {
    wp_enqueue_style('bootstrap', BEAULY_ASSETS_CSS_URL . 'bootstrap.min.css', []);
  }
  wp_enqueue_style('font-awesome-pro', BEAULY_ASSETS_CSS_URL . 'font-awesome-pro.min.css', []);
  wp_enqueue_style('flaticon-beauly', BEAULY_ASSETS_CSS_URL . 'flaticon-beauly.css', []);
  wp_enqueue_style('animate', BEAULY_ASSETS_CSS_URL . 'animate.min.css', []);
  wp_enqueue_style('nice-select', BEAULY_ASSETS_CSS_URL . 'nice-select.css', []);
  wp_enqueue_style('meanmenu', BEAULY_ASSETS_CSS_URL . 'meanmenu.css', []);
  wp_enqueue_style('owl-carousel', BEAULY_ASSETS_CSS_URL . 'owl-carousel.css', []);
  wp_enqueue_style('swiper-bundle', BEAULY_ASSETS_CSS_URL . 'swiper-bundle.css', []);
  wp_enqueue_style('datetimepicker', BEAULY_ASSETS_CSS_URL . 'datetimepicker.css', []);
  wp_enqueue_style('magnific-popup', BEAULY_ASSETS_CSS_URL . 'magnific-popup.css', []);
  wp_enqueue_style('odometer', BEAULY_ASSETS_CSS_URL . 'odometer.min.css', []);

  wp_enqueue_style('beauly-core', BEAULY_ASSETS_CSS_URL . 'beauly-core.css', [], BEAULY_THEME_VERSION);
  wp_enqueue_style('beauly-unit', BEAULY_ASSETS_CSS_URL . 'beauly-unit.css', [], BEAULY_THEME_VERSION);
  wp_enqueue_style('beauly-custom', BEAULY_ASSETS_CSS_URL . 'beauly-custom.css', [], BEAULY_THEME_VERSION);

  wp_enqueue_style('beauly-style', get_stylesheet_uri(), [], BEAULY_THEME_VERSION);

  /**
   * ---------------------------------------------------------------------------------------
   * Enqueue All JS Files
   * ---------------------------------------------------------------------------------------
   */
  wp_enqueue_script('bootstrap-bundle', BEAULY_ASSETS_JS_URL . 'bootstrap.bundle.min.js', ['jquery'], '', true);
  wp_enqueue_script('nice-select', BEAULY_ASSETS_JS_URL . 'nice-select.js', ['jquery'], '', true);
  wp_enqueue_script('waypoints', BEAULY_ASSETS_JS_URL . 'waypoints.js', ['jquery'], '', true);
  wp_enqueue_script('wow', BEAULY_ASSETS_JS_URL . 'wow.js', ['jquery'], '', true);
  wp_enqueue_script('meanmenu', BEAULY_ASSETS_JS_URL . 'meanmenu.js', ['jquery'], '', true);
  wp_enqueue_script('swiper-bundle', BEAULY_ASSETS_JS_URL . 'swiper-bundle.js', ['jquery'], '', true);
  wp_enqueue_script('owl-carousel', BEAULY_ASSETS_JS_URL . 'owl-carousel.js', ['jquery'], '', true);
  wp_enqueue_script('owl-carousel-filter', BEAULY_ASSETS_JS_URL . 'owl-carousel-filter.js', ['jquery'], '', true);
  wp_enqueue_script('magnific-popup', BEAULY_ASSETS_JS_URL . 'magnific-popup.js', ['jquery'], '', true);
  wp_enqueue_script('parallax', BEAULY_ASSETS_JS_URL . 'parallax.js', ['jquery'], '', true);
  wp_enqueue_script('smooth-scroll', BEAULY_ASSETS_JS_URL . 'smooth-scroll.js', ['jquery'], '', true);
  wp_enqueue_script('datetimepicker', BEAULY_ASSETS_JS_URL . 'datetimepicker.js', ['jquery'], '', true);
  wp_enqueue_script('odometer', BEAULY_ASSETS_JS_URL . 'odometer.min.js', ['jquery'], '', true);
  wp_enqueue_script('isotope', BEAULY_ASSETS_JS_URL . 'isotope.js', ['jquery', 'imagesloaded'], '', true);
  wp_enqueue_script('interactive-image', BEAULY_ASSETS_JS_URL . 'interactive-image.js', ['jquery'], '', true);

  wp_enqueue_script('beauly-main', BEAULY_ASSETS_JS_URL . 'main.js', ['jquery'], BEAULY_THEME_VERSION, true);

  if (is_singular() && comments_open() && get_option('thread_comments')) {
    wp_enqueue_script('comment-reply');
  }
}
add_action('wp_enqueue_scripts', 'beauly_scripts');

/**
 * ---------------------------------------------------------------------------------------
 * Register Google Fonts
 * ---------------------------------------------------------------------------------------
 */
function beauly_google_fonts_url() {
  $fonts_url     = '';
  $font_families = [];

  $OldStandardTT = _x('on', 'OldStandardTT font: on or off', 'beauly');
  $Jost       = _x('on', 'Jost font: on or off', 'beauly');

  if ('off' !== $OldStandardTT) {
    $font_families[] = 'Old Standard TT:ital,wght@0,400;0,700;1,400&display=swap';
  }
  if ('off' !== $Jost) {
    $font_families[] = 'Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap';
  }

  if ($font_families) {
    $query_args = array(
      'family' => urlencode(implode('|', $font_families)),
      'subset' => urlencode('latin,latin-ext'),
    );
    $fonts_url = add_query_arg($query_args, '//fonts.googleapis.com/css');
  }

  return $fonts_url;
}
