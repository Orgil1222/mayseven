<?php

/**
 * Beauly Theme Widgets Register
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

if (!defined('ABSPATH')) {
  exit;
}

/**
 *    ---------------------------------------------------------------------------------------
 *    Register widget area.
 *    ---------------------------------------------------------------------------------------
 */

/**
 * blog sidebar
 */
register_sidebar([
  'name'          => esc_html__('Blog Sidebar', 'beauly'),
  'id'            => 'blog-sidebar',
  'before_widget' => '<div id="%1$s" class="tj-sidebar__widget wow fadeInUp sidebar-item %2$s" data-wow-delay="0.4s">',
  'after_widget'  => '</div>',
  'before_title'  => '<div class="tj-sidebar-widget__head sidebar-header"><h3 class="tj-sidebar-widget__title sidebar-title">',
  'after_title'   => '</h3></div>',
]);


$footer_columns = get_theme_mod('footer_widget_column', 4);
$footer_style_2_switch = get_theme_mod('footer_style_2_switch', false);
$footer_style_3_switch = get_theme_mod('footer_style_3_switch', false);

// footer default
for ($num = 1; $num <= $footer_columns; $num++) {
  register_sidebar([
    'name'          => sprintf(esc_html__('Footer Column %1$s', 'beauly'), $num),
    'id'            => 'footer-' . $num,
    'description'   => sprintf(esc_html__('This widget content will be show widget %1$s', 'beauly'), $num),
    'before_widget' => '<div id="%1$s" class="beauly-widget footer-1-col-' . $num . ' tj-footer__widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h3 class="tj-footer-widget_title widget-header-title">',
    'after_title'   => '</h3>',
  ]);
}

// footer 2
if ($footer_style_2_switch) {
  for ($num = 1; $num <= $footer_columns; $num++) {

    register_sidebar([
      'name'          => sprintf(esc_html__('Footer Style 2 : Column %1$s', 'beauly'), $num),
      'id'            => 'footer-2-' . $num,
      'description'   => sprintf(esc_html__('Footer Style 2 : Column %1$s Widgets', 'beauly'), $num),
      'before_widget' => '<div id="%1$s" class="tj-footer__widget beauly-widget footer-2-col-' . $num . ' %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="tj-footer-widget_title widget-header-title">',
      'after_title'   => '</h3>',
    ]);
  }
}

// footer 3
if ($footer_style_3_switch) {
  for ($num = 1; $num <= $footer_columns; $num++) {
    register_sidebar([
      'name'          => sprintf(esc_html__('Footer Style 3 : Column %1$s', 'beauly'), $num),
      'id'            => 'footer-3-' . $num,
      'description'   => sprintf(esc_html__('Footer Style 3 : Column %1$s Widgets', 'beauly'), $num),
      'before_widget' => '<div id="%1$s" class="tj-footer__widget beauly-widget footer-3-col-' . $num . ' %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="tj-footer-widget_title widget-header-title">',
      'after_title'   => '</h3>',
    ]);
  }
}
