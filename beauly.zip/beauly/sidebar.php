<?php

/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

if (!is_active_sidebar('blog-sidebar')) {
	return;
}
?>

	<?php dynamic_sidebar('blog-sidebar'); ?>