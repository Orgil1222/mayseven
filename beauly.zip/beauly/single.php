<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

get_header();


$blog_column = is_active_sidebar('blog-sidebar') ? 8 : 10;
$beauly_blog_social = get_theme_mod('beauly_blog_social', false);
?>

<div class="tj-post-details__area blog-details padding">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-<?php print esc_attr($blog_column); ?>">
				<!-- post details container -->
				<div class="tj-post-details__container blog-wrapper">
					<?php
					while (have_posts()) :
						the_post();

						get_template_part('template-parts/content', get_post_format());
					?>

						<?php if (has_tag() || !empty($beauly_blog_social)) : ?>
							<!-- post tag & share -->
							<div class="single-blog-tag-share <?php echo (!empty($beauly_blog_social) ? "" : "no-social-share"); ?>">
								<!-- post tags -->
								<?php if (has_tag()) {
									echo beauly_get_tag();
								}

								// post share
								if (!empty($beauly_blog_social)) : ?>
									<div class="shear-link">
										<a href="https://www.facebook.com/sharer?u=<?php the_permalink(); ?>" target="_blank" rel="noopener noreferrer" class="facebook" title="Share this on Facebook"><i class="fa-brands fa-facebook-f"></i></a>
										<a href="http://twitter.com/intent/tweet?url=<?php the_permalink(); ?>" class="twitter" title="Share this on Twitter" target="_blank"><i class="fa-brands fa-x-twitter"></i></a>
										<a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink() ?>&amp;summary=&amp;source=<?php bloginfo('name'); ?>" class="linkedin" title="Share this on Linkedin" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>


						<?php if (get_previous_post_link() || get_next_post_link()) : ?>
							<!-- post pagination -->
							<div class="blog-details__pagination">

								<!-- previous post -->
								<?php
								$prevPost = get_adjacent_post(false, '', true);;
								?>

								<?php if (is_a($prevPost, 'WP_Post')) :

									$prevThumbnail = get_the_post_thumbnail($prevPost->ID, [85, 85]);
									$prevTittle = $prevPost->post_title;
									$prevLink = get_permalink($prevPost->ID);
								?>
									<div class="tj_pagination-post previous">

										<div class="tj_pagination_post-inner prev_post">
											<?php if (!empty($prevThumbnail)) : ?>
												<div class="tj-blog-img">
													<a href="<?php echo esc_url($prevLink); ?>">
														<?php echo beauly_kses($prevThumbnail); ?>
													</a>
												</div>
											<?php endif; ?>
											<div class="tj-content">
												<div class="post_pagination_nav">
													<i class="fa-regular fa-angle-double-left"></i><?php echo esc_html__('previous', 'beauly'); ?>
												</div>
												<div class="post_pagination_title">
													<h5 class="title">
														<a href="<?php echo esc_url($prevLink); ?>"><?php echo wp_trim_words($prevTittle, 8, '...'); ?></a>
													</h5>
												</div>
											</div>
										</div>
									</div>
								<?php endif; ?>

								<!-- next post -->
								<?php
								$nextPost = get_adjacent_post(false, '', false);
								?>

								<?php
								if (is_a($nextPost, 'WP_Post')) :

									$nextThumbnail = get_the_post_thumbnail($nextPost->ID, [85, 85]);
									$nextTittle = $nextPost->post_title;
									$nextLink = get_permalink($nextPost->ID);
								?>
									<div class="tj_pagination-post next">

										<div class="tj_pagination_post-inner next_post">

											<div class="tj-content">
												<div class="post_pagination_nav">
													<?php echo esc_html__('Next', 'beauly'); ?><i class="fa-regular fa-angle-double-right"></i>
												</div>
												<div class="post_pagination_title">
													<h5 class="title">
														<a href="<?php echo esc_url($nextLink); ?>"><?php echo wp_trim_words($nextTittle, 8, '...'); ?></a>
													</h5>
												</div>
											</div>
											<?php if (!empty($nextThumbnail)) : ?>
												<div class="tj-blog-img">
													<div class="tj-img">
														<a href="<?php echo esc_url($nextLink); ?>">
															<?php echo beauly_kses($nextThumbnail); ?>
														</a>
													</div>
												</div>
											<?php endif; ?>
										</div>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>


					<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if (comments_open() || get_comments_number()) :
							comments_template();
						endif;

					endwhile; // End of the loop.
					?>
				</div>
				<!-- !post details container -->
			</div>

			<?php if (is_active_sidebar('blog-sidebar')) : ?>
				<!-- sidebar -->
				<div class="col-lg-4">
					<aside class="tj-main__sidebar sidebar-wrapper">
						<?php get_sidebar(); ?>
					</aside>
				</div> <!-- !sidebar -->
			<?php endif; ?>

		</div>
	</div>
</div>

<?php
get_footer();
