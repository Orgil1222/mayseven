<?php

/**
 * Template part for displaying footer layout Two
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

// from page
$enable_footer_settings = function_exists('get_field') ? get_field('enable_footer_settings') : false;
$page_footer_bg_img = function_exists('get_field') ? get_field('page_footer_bg_img') : '';
$page_footer_bg_color = function_exists('get_field') ? get_field('page_footer_bg_color') : '#1a1b1d';
$page_footer_menu = function_exists('get_field') ? get_field('page_footer_menu') : false;

// multifunction
if (!empty($enable_footer_settings)) {
  $footerBgImage = !empty($page_footer_bg_img['url']) ? $page_footer_bg_img['url'] : get_theme_mod('footer_bg_img');
  $footerBgColor = !empty($page_footer_bg_color) ? $page_footer_bg_color : get_theme_mod('footer_bg_color', '#1a1b1d');

  $footerMenu = $page_footer_menu;
  $footerCopyrightMiddleClass = !empty($footerMenu) ? 'justify-content-between' : 'justify-content-center';
} else {
  $footerBgImage = get_theme_mod('footer_bg_img');
  $footerBgColor = get_theme_mod('footer_bg_color', '#222326');

  $footerMenu = get_theme_mod('footer_menu_switcher', false);
  $footerCopyrightMiddleClass = !empty($footerMenu) ? 'justify-content-between' : 'justify-content-center';
}

// footer_columns
$footer_column = 0;
$footer_column = get_theme_mod('footer_widget_column', 4);


for ($num = 1; $num <= $footer_column; $num++) {
  switch ($num) {
    case '1':
      $footer_class[1] = 'col-12';
      break;
    case '2':
      $footer_class[1] = 'col-md-6';
      $footer_class[2] = 'col-md-6';
      break;
    case '3':
      $footer_class[1] = 'col-lg-4 col-md-6';
      $footer_class[2] = 'col-lg-4 col-md-6';
      $footer_class[3] = 'col-lg-4 col-md-6';
      break;
    case '4':
      $footer_class[1] = 'col-lg-3 col-md-6';
      $footer_class[2] = 'col-lg-3 col-md-6';
      $footer_class[3] = 'col-lg-3 col-md-6';
      $footer_class[4] = 'col-lg-3 col-md-6';
      break;
    default:
      $footer_class = 'col-lg-3 col-md-6';
      break;
  }
} ?>


<!-- Footer area -->
<footer class="footer-area footer-2" <?php if (!empty($footerBgColor)) : ?>data-bg-color="<?php echo esc_attr($footerBgColor); ?>" <?php endif;
                                                                                                                                  if (!empty($footerBgImage)) : ?> data-background="<?php echo esc_url($footerBgImage); ?>" <?php endif; ?>>

  <?php if (is_active_sidebar('footer-2-1') or is_active_sidebar('footer-2-2') or is_active_sidebar('footer-2-3') or is_active_sidebar('footer-2-4')) : ?>
    <div class="footer-top">
      <div class="container">
        <div class="row justify-content-center">
          <?php
          for ($num = 1; $num <= $footer_column; $num++) {

            echo '<div class="' . esc_attr($footer_class[$num]) . '">';
            dynamic_sidebar('footer-2-' . $num);
            echo '</div>';
          }
          ?>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="footer-content d-flex align-items-center <?php echo esc_attr($footerCopyrightMiddleClass); ?>">
            <div class="footer-left">
              <p><?php echo beauly_copyright_text(); ?></p>
            </div>

            <?php if (!empty($footerMenu)) : ?>
              <div class="footer-right">
                <?php if (has_nav_menu('footer-menu')) {
                  beauly_footer_menu();
                } ?>
              </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- ./ Footer area -->