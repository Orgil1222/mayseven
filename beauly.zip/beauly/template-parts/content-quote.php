<?php

/**
 * Template part for displaying quote posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */
?>
<!-- post-<?php the_ID(); ?> -->
<article <?php post_class("tj__post post-card wow fadeInUp"); ?> id="post-<?php the_ID(); ?>" data-wow-delay="0.4s">
  <?php the_content(); ?>
</article><!-- !post-<?php the_ID(); ?> -->