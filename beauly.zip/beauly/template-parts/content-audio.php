<?php

/**
 * Template part for displaying audio posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

// get audio url
$beauly_audio_url = function_exists('get_field') ? get_field('post_audio_link') : NULL;

if (is_single()) : ?>

  <!-- single post -->
  <article id="post-<?php the_ID(); ?>" <?php post_class("tj-single__post tj-blog"); ?>>
    <?php if (!empty($beauly_audio_url)) : ?>
      <!-- post thumbnail -->
      <div class="tj-post__thumb blog-details-thumb">
        <?php echo wp_oembed_get($beauly_audio_url); ?>
      </div>
    <?php endif; ?>

    <div class="tj-post__content">
      <!-- entry title -->
      <?php the_title('<h2 class="tj-post__title entry-title tj-blog-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>'); ?>

      <!-- entry-meta -->
      <?php get_template_part('template-parts/blog/post-meta'); ?>

      <!-- entry content -->
      <div class="tj-entry__content">

        <?php the_content(); ?>

        <?php
        wp_link_pages([
          'before'      => '<div class="tj-page__links"> <span class="tj-page-links__title">' . esc_html__('Pages:', 'beauly') . '</span>',
          'after'       => '</div>',
          'link_before' => '<span>',
          'link_after'  => '</span>',
          'pagelink'    => '<span class="screen-reader-text">' . esc_html__('Page', 'beauly') . ' </span>%',
          'separator'   => '<span class="screen-reader-text"> </span>',
        ]);
        ?>
      </div>
    </div>
  </article>
  <!-- !single post -->

<?php else : ?>

  <!-- post-<?php the_ID(); ?> -->
  <article <?php post_class("tj__post post-card wow fadeInUp"); ?> id="post-<?php the_ID(); ?>" data-wow-delay="0.4s">

    <?php if (!empty($beauly_audio_url)) : ?>
      <!-- post thumbnail -->
      <div class="tj_post-thumb">
        <?php echo wp_oembed_get($beauly_audio_url); ?>
      </div>
    <?php endif; ?>

    <div class="tj-post__content post-content">

      <!-- entry-meta -->
      <?php get_template_part('template-parts/blog/post-meta'); ?>

      <!-- entry title -->
      <?php the_title('<h3 class="tj-post__title entry-title post-content-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>

      <!-- post excerpt -->
      <div class="blog-stander__text">
        <?php echo wp_trim_words(get_the_content(), '40', '...'); ?>
      </div>

      <!-- post btn -->
      <?php get_template_part('template-parts/blog/post-btn'); ?>

    </div>
    <div class="tj-clearfix"></div>
  </article><!-- !post-<?php the_ID(); ?> -->

<?php endif; ?>