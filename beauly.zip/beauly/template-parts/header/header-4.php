<?php

/**
 * Template part for displaying header layout four
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

// from Page
$enable_header_settings = function_exists('get_field') ? get_field('enable_header_settings') : false;
$is_page_header_sticky = function_exists('get_field') ? get_field('is_page_header_sticky') : false;
$is_page_header_absolute = function_exists('get_field') ? get_field('is_page_header_absolute') : false;
$page_header_button = function_exists('get_field') ? get_field('page_header_button') : false;
$page_header_button_text = function_exists('get_field') ? get_field('page_header_button_text') : esc_html__('Schedule a Visit', 'beauly');
$page_header_button_link = function_exists('get_field') ? get_field('page_header_button_link') : esc_html__('#', 'beauly');

$showPageHeaderTopBar = function_exists('get_field') ? get_field('page_header_topbar') : false;
$showPageHeaderTopEmail = function_exists('get_field') ? get_field('page_header_topbar_email') : false;
$showPageHeaderTopContactNo = function_exists('get_field') ? get_field('page_header_topbar_contact_no') : false;
$showPageHeaderTopSocials = function_exists('get_field') ? get_field('page_header_topbar_socials') : false;

// info
$header_sticky = get_theme_mod('header_sticky', false);
$header_absolute = get_theme_mod('header_absolute', false);
$header_contact_number = get_theme_mod('contact_phone_number', esc_html__('+000-723-123-21', 'beauly'));
$contact_email = get_theme_mod('contact_email', esc_html__('beaulycontact@gmail.com', 'beauly'));

// multi condition
if (!empty($enable_header_settings)) {
  $isHeaderSticky = !empty($is_page_header_sticky) ? "isSticky" : "";
  $isHeaderAbsolute = !empty($is_page_header_absolute) ? "absolute" : "";

  // button
  $showHeaderRightButton = $page_header_button;
  $buttonText = !empty($page_header_button_text) ? $page_header_button_text : get_theme_mod('header_right_button_text', esc_html__('Schedule a Visit', 'beauly'));
  $buttonLink = !empty($page_header_button_link) ? $page_header_button_link : get_theme_mod('header_right_button_link', esc_html__('#', 'beauly'));

  // topbar
  $showHeaderTopbar = $showPageHeaderTopBar;
  $showTopBarEmail = $showPageHeaderTopEmail;
  $showTopBarPhone = $showPageHeaderTopContactNo;
  $showTopBarSocials = $showPageHeaderTopSocials;
} else {

  $isHeaderSticky = !empty($header_sticky) ? "isSticky" : "";
  $isHeaderAbsolute = !empty($header_absolute) ? "absolute" : "";

  // button
  $showHeaderRightButton = get_theme_mod('header_right_button', false);
  $buttonText = get_theme_mod('header_right_button_text', esc_html__('Schedule a Visit', 'beauly'));
  $buttonLink = get_theme_mod('header_right_button_link', esc_html__('#', 'beauly'));

  // topbar
  $showHeaderTopbar = get_theme_mod('beauly_topbar_switch', true);
  $showTopBarEmail = get_theme_mod('topbar_email_switcher', true);
  $showTopBarPhone = get_theme_mod('topbar_contact_no_switcher', true);
  $showTopBarSocials = get_theme_mod('topbar_socials', true);
}


// mobile topbar
$showMobileTopbar = get_theme_mod('beauly_topbar_mobile_switch', true);
$showTopBarMobileEmail = get_theme_mod('topbar_mobile_email_switcher', true);
$showTopBarMobileContactNo = get_theme_mod('topbar_mobile_contact_no_switcher', true);
$showTopBarMobileSocials = get_theme_mod('topbar_mobile_socials_switcher', true);
?>
<header class="header header-4 <?php printf("%s", esc_attr($isHeaderAbsolute)); ?>">

  <?php if (!empty($showHeaderTopbar)) : ?>
    <div class="top-bar <?php echo !empty($showMobileTopbar) ? "" : "d-none d-md-flex"; ?>">
      <div class="top-left-content">
        <ul>

          <?php if (!empty($showTopBarPhone && $header_contact_number)) : ?>
            <li class="<?php echo !empty($showTopBarMobileContactNo) ? "" : "d-none d-md-inline-block"; ?>">
              <a href="tel:<?php echo esc_attr($header_contact_number); ?>"><i class="fa-regular fa-phone"></i><?php echo esc_html($header_contact_number); ?></a>
            </li>
          <?php endif; ?>

          <?php if (!empty($showTopBarEmail && $contact_email)) : ?>
            <li class="<?php echo !empty($showTopBarMobileEmail) ? "" : "d-none d-md-inline-block"; ?>">
              <a href="mailto:<?php echo esc_attr($contact_email); ?>"><i class="flaticon-mail"></i><?php echo esc_html($contact_email); ?></a>
            </li>
          <?php endif; ?>
        </ul>
      </div>

      <?php if (!empty($showTopBarSocials)) : ?>
        <div class="top-right-content <?php echo !empty($showTopBarMobileSocials) ? "" : "d-none d-md-inline-flex"; ?>">
          <?php beauly_header_socials(); ?>
        </div>
      <?php endif; ?>
    </div>
    <!-- ./ top bar -->
  <?php endif; ?>

  <div class="main-header">
    <div class="primary-header">
      <div class="primary-header-inner">
        <div class="header-logo">
          <?php beauly_header_logo(); ?>
        </div>
        <div class="header-menu-wrap mobile-menu-items d-none d-lg-inline-flex">
          <?php beauly_header_menu(); ?>
        </div>
        <!-- /.header-menu-wrap -->

        <?php if (!empty($buttonText && $showHeaderRightButton)) : ?>
          <div class="header-right d-none d-md-inline-flex">
            <a class="header-btn tj-primary-btn" href="<?php echo esc_url($buttonLink); ?>"><?php echo esc_html($buttonText); ?><i class="fa-light fa-arrow-right-long"></i></a>
          </div>
        <?php endif; ?>

        <a href="javascript:void(0)" class="mobile-side-menu-toggle d-lg-none"><i class="fa-sharp fa-regular fa-bars-sort"></i></a>
        <!-- /.header-right -->
      </div>
      <!-- /.primary-header-inner -->
    </div>
    <!-- /.primary-header -->
  </div>
</header>

<header class="header header-4 sticky-header <?php printf("%s", esc_attr($isHeaderSticky)); ?>">
  <div class="main-header">
    <div class="primary-header">
      <div class="primary-header-inner">
        <div class="header-logo">
          <?php beauly_header_logo(); ?>
        </div>
        <div class="header-menu-wrap mobile-menu-items d-none d-lg-inline-flex">
          <?php beauly_header_menu(); ?>
        </div>
        <!-- /.header-menu-wrap -->

        <?php if (!empty($buttonText && $showHeaderRightButton)) : ?>
          <div class="header-right d-none d-md-inline-flex">
            <a class="header-btn tj-primary-btn" href="<?php echo esc_url($buttonLink); ?>"><?php echo esc_html($buttonText); ?><i class="fa-light fa-arrow-right-long"></i></a>
          </div>
        <?php endif; ?>

        <a href="javascript:void(0)" class="mobile-side-menu-toggle d-lg-none"><i class="fa-sharp fa-regular fa-bars-sort"></i></a>
        <!-- /.header-right -->
      </div>
      <!-- /.primary-header-inner -->
    </div>
    <!-- /.primary-header -->
  </div>
</header>