<?php

/**
 * Template part for displaying header layout two
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */


// from Page
$enable_header_settings = function_exists('get_field') ? get_field('enable_header_settings') : false;
$is_page_header_sticky = function_exists('get_field') ? get_field('is_page_header_sticky') : false;
$is_page_header_absolute = function_exists('get_field') ? get_field('is_page_header_absolute') : false;
$page_contact_number = function_exists('get_field') ? get_field('page_contact_number') : false;
$page_header_button = function_exists('get_field') ? get_field('page_header_button') : false;
$page_header_button_text = function_exists('get_field') ? get_field('page_header_button_text') : esc_html__('Schedule a Visit', 'beauly');
$page_header_button_link = function_exists('get_field') ? get_field('page_header_button_link') : esc_html__('#', 'beauly');

// info
$phoneNumber = get_theme_mod('contact_phone_number', esc_html__('+000-723-123-21', 'beauly'));
$header_sticky = get_theme_mod('header_sticky', false);
$header_absolute = get_theme_mod('header_absolute', false);

// multi condition
if (!empty($enable_header_settings)) {
  $isHeaderSticky = !empty($is_page_header_sticky) ? "isSticky" : "";
  $isHeaderAbsolute = !empty($is_page_header_absolute) ? "absolute" : "";

  // header phone
  $showHeaderRightPhoneNo = $page_contact_number;

  // button
  $showHeaderRightButton = $page_header_button;
  $buttonText = !empty($page_header_button_text) ? $page_header_button_text : get_theme_mod('header_right_button_text', esc_html__('Schedule a Visit', 'beauly'));
  $buttonLink = !empty($page_header_button_link) ? $page_header_button_link : get_theme_mod('header_right_button_link', esc_html__('#', 'beauly'));
} else {

  $isHeaderSticky = !empty($header_sticky) ? "isSticky" : "";
  $isHeaderAbsolute = !empty($header_absolute) ? "absolute" : "";

  // header phone
  $showHeaderRightPhoneNo = get_theme_mod('header_right_phone', false);

  // button
  $showHeaderRightButton = get_theme_mod('header_right_button', false);
  $buttonText = get_theme_mod('header_right_button_text', esc_html__('Schedule a Visit', 'beauly'));
  $buttonLink = get_theme_mod('header_right_button_link', esc_html__('#', 'beauly'));
}
?>
<!-- header-area-start -->
<header class="header <?php printf("%s %s", esc_attr($isHeaderAbsolute), esc_attr($isHeaderSticky)); ?>">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="primary-header">
          <div class="primary-header-inner">

            <div class="header-logo d-lg-none">
              <?php beauly_header_vertical_logo(); ?>
            </div>

            <div class="header-contact-area">
              <?php if (!empty($showHeaderRightPhoneNo && $phoneNumber)) : ?>
                <a href="tel:<?php echo esc_attr($phoneNumber); ?>"><i class="fa-regular fa-phone"></i><?php echo esc_html($phoneNumber); ?></a>
              <?php endif; ?>
            </div>

            <div class="header-menu-wrap move_logo_wrap d-none d-lg-block">
              <div class="header-logo">
                <?php beauly_header_vertical_logo(); ?>
              </div>

              <nav class="mobile-menu-items">
                <?php beauly_header_menu(); ?>
              </nav>
            </div> <!-- /.header-menu-wrap -->

            <div class="header-right d-none d-md-inline-flex align-items-center justify-content-end">
              <?php if (!empty($buttonText && $showHeaderRightButton)) : ?>
                <a class="header-btn tj-primary-btn" href="<?php echo esc_url($buttonLink); ?>"><?php echo esc_html($buttonText); ?><i class="fa-light fa-arrow-right-long"></i></a>
              <?php endif; ?>
            </div>

            <a href="javascript:void(0)" class="mobile-side-menu-toggle d-lg-none"><i class="fa-regular fa-bars-sort"></i></a>
            <!-- /.header-right -->
          </div>
          <!-- /.primary-header-inner -->
        </div>
        <!-- /.primary-header -->
      </div>
    </div>
  </div>
</header>
<!-- /.Main Header -->