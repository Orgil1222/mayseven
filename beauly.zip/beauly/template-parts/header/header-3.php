<?php

/**
 * Template part for displaying header layout three
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

// from Page
$enable_header_settings = function_exists('get_field') ? get_field('enable_header_settings') : false;
$is_page_header_sticky = function_exists('get_field') ? get_field('is_page_header_sticky') : false;
$is_page_header_absolute = function_exists('get_field') ? get_field('is_page_header_absolute') : false;
$page_header_sidebar = function_exists('get_field') ? get_field('page_header_sidebar') : false;
$page_header_sidebar_title = function_exists('get_field') ? get_field('page_header_sidebar_title') : esc_html__('Here is a Quick Search Through All of Our Apartments.', 'beauly');
$page_show_apartments = function_exists('get_field') ? get_field('page_show_apartments') : '6';
$page_choose_apartments = function_exists('get_field') ? get_field('page_choose_apartments') : '';
$page_header_button = function_exists('get_field') ? get_field('page_header_button') : false;
$page_header_button_text = function_exists('get_field') ? get_field('page_header_button_text') : esc_html__('Schedule a Visit', 'beauly');
$page_header_button_link = function_exists('get_field') ? get_field('page_header_button_link') : esc_html__('#', 'beauly');

// info
$header_sticky = get_theme_mod('header_sticky', false);
$header_absolute = get_theme_mod('header_absolute', false);



// multi condition
if (!empty($enable_header_settings)) {
  $isHeaderSticky = !empty($is_page_header_sticky) ? "isSticky" : "";
  $isHeaderAbsolute = !empty($is_page_header_absolute) ? "absolute" : "";

  // sidebar
  $header_right_sidebar = $page_header_sidebar;
  $sidebar_title = !empty($page_header_sidebar_title) ? $page_header_sidebar_title : get_theme_mod('sidebar_title', esc_html__('Here is a Quick Search Through All of Our Apartments.', 'beauly'));
  $show_apartments = !empty($page_show_apartments) ? $page_show_apartments : get_theme_mod('show_apartments', 6);
  $choose_apartments = !empty($page_choose_apartments) ? $page_choose_apartments : get_theme_mod('choose_apartments', '');

  // button
  $showHeaderRightButton = $page_header_button;
  $buttonText = !empty($page_header_button_text) ? $page_header_button_text : get_theme_mod('header_right_button_text', esc_html__('Schedule a Visit', 'beauly'));
  $buttonLink = !empty($page_header_button_link) ? $page_header_button_link : get_theme_mod('header_right_button_link', esc_html__('#', 'beauly'));
} else {

  $isHeaderSticky = !empty($header_sticky) ? "isSticky" : "";
  $isHeaderAbsolute = !empty($header_absolute) ? "absolute" : "";

  // sidebar
  $header_right_sidebar = get_theme_mod('header_right_sidebar', false);
  $sidebar_title = get_theme_mod('sidebar_title', esc_html__('Here is a Quick Search Through All of Our Apartments.', 'beauly'));
  $show_apartments = get_theme_mod('show_apartments', 6);
  $choose_apartments = get_theme_mod('choose_apartments', '');

  // button
  $showHeaderRightButton = get_theme_mod('header_right_button', false);
  $buttonText = get_theme_mod('header_right_button_text', esc_html__('Schedule a Visit', 'beauly'));
  $buttonLink = get_theme_mod('header_right_button_link', esc_html__('#', 'beauly'));
}
?>

<!-- header-area-start -->
<header class="header header-3 <?php printf("%s %s", esc_attr($isHeaderAbsolute), esc_attr($isHeaderSticky)); ?>">

  <?php if (!empty($header_right_sidebar)) : ?>
    <div class="side-menu-icon">
      <span></span>
      <span></span>
      <span></span>
    </div>
  <?php endif; ?>

  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="primary-header">
          <div class="primary-header-inner">
            <div class="header-logo">
              <?php beauly_header_logo(); ?>
            </div>
            <div class="header-menu-wrap mobile-menu-items">
              <?php beauly_header_menu(); ?>
            </div>
            <!-- /.header-menu-wrap -->

            <?php if (!empty($buttonText && $showHeaderRightButton)) : ?>
              <div class="header-right d-none d-md-inline-flex">
                <a class="header-btn tj-primary-btn" href="<?php echo esc_url($buttonLink); ?>"><?php echo esc_html($buttonText); ?><i class="fa-light fa-arrow-right-long"></i></a>
              </div>
            <?php endif; ?>

            <a href="javascript:void(0)" class="mobile-side-menu-toggle d-lg-none"><i class="fa-regular fa-bars-sort"></i></a>
            <!-- /.header-right -->
          </div>
          <!-- /.primary-header-inner -->
        </div>
        <!-- /.primary-header -->
      </div>
    </div>
  </div>
</header>
<!-- /.Main Header -->


<?php if (!empty($header_right_sidebar)) :

  // Posts Include array
  $pI_ids = [];
  if (!empty($choose_apartments)) {
    foreach ($choose_apartments as $pI_idsn) {
      $pI_ids[] = $pI_idsn;
    }
  }
  // args
  $args = array(
    'post_type' => 'apartments',
    'post_status' => 'publish',
    'posts_per_page' => $show_apartments,
    'order' => 'desc',
    'post__in' => $pI_ids,
  );


  // The Query
  $query = new \WP_Query($args); ?>
  <div class="side-menu-wrapper d-none d-lg-block">
    <button class="side-menu-close"><i class="fa-thin fa-times"></i></button>
    <div class="side-menu-content">

      <?php if (!empty($sidebar_title)) : ?>
        <h2 class="side-menu-header"><?php echo esc_html($sidebar_title); ?></h2>
      <?php endif; ?>

      <?php if ($query->have_posts()) : ?>
        <div class="side-menu-items">
          <?php while ($query->have_posts()) : $query->the_post(); ?>
            <div class="side-menu-item bg-dark-light">
              <div class="side-menu-thumb-box">
                <?php if (has_post_thumbnail()) :
                  the_post_thumbnail('medium');
                endif;
                ?>
                <div class="side-menu-info">
                  <h3 class="side-menu-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                  <?php if (get_the_excerpt()) : ?>
                    <p><?php echo wp_trim_words(get_the_excerpt(), 16, '...'); ?></p>
                  <?php endif; ?>
                </div>
              </div>
              <div class="side-menu-arrow"><i class="fa-regular fa-arrow-right"></i></div>
            </div>
          <?php endwhile;
          wp_reset_query(); ?>

        </div>
      <?php else :

        printf("%s", __('No Apartment Available', 'beauly'));

      endif;
      ?>

    </div>
  </div>
  <div class="side-menu-overlay"></div>
<?php endif; ?>