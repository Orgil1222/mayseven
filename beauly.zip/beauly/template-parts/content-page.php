<?php

/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

?>
<!-- page-<?php the_ID(); ?> -->
<div id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if (has_post_thumbnail()) : ?>
		<!-- page thumbnail -->
		<div class="tj-post__thumb">
			<?php the_post_thumbnail('full', ['class' => 'img-responsive']); ?>
		</div>
	<?php endif; ?>

	<!-- page content -->
	<div class="tj-entry__content">

		<?php the_content(); ?>

	</div>

	<?php
	wp_link_pages([
		'before'      => '<div class="tj-page__links"> <span class="tj-page-links__title">' . esc_html__('Pages:', 'beauly') . '</span>',
		'after'       => '</div>',
		'link_before' => '<span>',
		'link_after'  => '</span>',
		'pagelink'    => '<span class="screen-reader-text">' . esc_html__('Page', 'beauly') . ' </span>%',
		'separator'   => '<span class="screen-reader-text"> </span>',
	]);
	?>

	<?php
	if (comments_open() || get_comments_number()) :
		comments_template();
	endif;
	?>
</div> <!-- !page-<?php the_ID(); ?> -->