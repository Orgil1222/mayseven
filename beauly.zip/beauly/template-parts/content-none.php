<?php

/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

?>

<div class="no-results not-found">
	<div class="tj-page__header">
		<h2 class="page__title"><?php esc_html_e('Nothing Found', 'beauly'); ?></h2>
	</div>

	<div class="tj-entry__content">
		<?php
		if (is_home() && current_user_can('publish_posts')) :

			printf(
				'<p>' . wp_kses(
					/* translators: 1: link to WP admin new post page. */
					__('Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'beauly'),
					[
						'a' => [
							'href' => [],
						],
					]
				) . '</p>',
				esc_url(admin_url('post-new.php'))
			);

		elseif (is_search()) :
		?>

			<p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'beauly'); ?></p>
		<?php
			get_search_form();
		else :
		?>

			<p><?php esc_html_e('It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'beauly'); ?></p>
		<?php
			get_search_form();

		endif;
		?>
	</div><!-- !page content -->
</div><!-- no results -->