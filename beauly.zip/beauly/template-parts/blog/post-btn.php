<?php

/**
 * Template part for displaying post btn
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

$beauly_blog_btn_switch = get_theme_mod('beauly_blog_btn_switch', true);
$beauly_blog_btn = get_theme_mod('beauly_blog_btn', 'Read More');

?>

<?php if (!empty($beauly_blog_btn_switch)) : ?>
  <div class="tj-post__btn">
    <a href="<?php the_permalink(); ?>" class="tj-primary-btn"><?php echo esc_html($beauly_blog_btn); ?> <i class="fa-light fa-arrow-right-long"></i></a>
  </div>
<?php endif; ?>