<?php

/**
 * Template part for displaying post meta
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

$categories = get_the_terms($post->ID, 'category');
$beauly_blog_date = get_theme_mod('beauly_blog_date', true);
$beauly_blog_comments = get_theme_mod('beauly_blog_comments', true);
$beauly_blog_author = get_theme_mod('beauly_blog_author', true);
$beauly_blog_cat = get_theme_mod('beauly_blog_cat', false);

?>
<div class="tj-post__meta entry-meta post-meta d-flex align-items-center">
  <ul>

    <?php if (!empty($beauly_blog_cat)) : ?>
      <?php if (!empty($categories)) : ?>
        <li class="category"><a href="<?php echo esc_url(get_category_link($categories[0]->term_id)); ?>"><?php echo esc_html($categories[0]->name); ?></a></li>
      <?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($beauly_blog_author)) : ?>
      <li><i class="fa-light fa-user"></i><?php printf('%s <a href="%s">%s</a>', esc_html__('By', 'beauly'), esc_url(get_author_posts_url(get_the_author_meta('ID'))), get_the_author()); ?></li>
    <?php endif; ?>

    <?php if (!empty($beauly_blog_date)) : ?>
      <li><i class="fa-light fa-clock"></i> <?php the_time(get_option('date_format')); ?></li>
    <?php endif; ?>

    <?php if (!empty($beauly_blog_comments)) : ?>
      <li><a href="<?php comments_link(); ?>"><i class="fa-light fa-comments-alt"></i> <?php comments_number(); ?></a></li>
    <?php endif; ?>
  </ul>
</div>