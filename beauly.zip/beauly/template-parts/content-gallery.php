<?php

/**
 * Template part for displaying gallery posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauly_Theme
 * @since Beauly 1.0.0
 * @author ThemeJunction 
 */

// get gallery images
$gallery_images = function_exists('get_field') ? get_field('post_gallery_images') : '';

if (is_single()) : ?>

  <!-- single post -->
  <article id="post-<?php the_ID(); ?>" <?php post_class("tj-single__post tj-blog"); ?>>

    <?php if (!empty($gallery_images)) : ?>
      <!-- post gallery -->
      <div class="tj-post__thumb blog-details-thumb">
        <div class="tj-post__gallery swiper-container p-relative">
          <div class="swiper-wrapper">
            <?php foreach ($gallery_images as $key => $image) : ?>
              <div class="tj-post-gallery__image swiper-slide">
                <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
              </div>
            <?php endforeach; ?>
          </div>
          <div class="tj-post-gallery__nav">
            <button class="tj-gallery-button__next"><i class="fal fa-arrow-right"></i></button>
            <button class="tj-gallery-button__prev"><i class="fal fa-arrow-left"></i></button>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <div class="tj-post__content">
      <!-- entry title -->
      <?php the_title('<h2 class="tj-post__title entry-title tj-blog-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>'); ?>

      <!-- entry-meta -->
      <?php get_template_part('template-parts/blog/post-meta'); ?>

      <!-- entry content -->
      <div class="tj-entry__content">

        <?php the_content(); ?>

        <?php
        wp_link_pages([
          'before'      => '<div class="tj-page__links"> <span class="tj-page-links__title">' . esc_html__('Pages:', 'beauly') . '</span>',
          'after'       => '</div>',
          'link_before' => '<span>',
          'link_after'  => '</span>',
          'pagelink'    => '<span class="screen-reader-text">' . esc_html__('Page', 'beauly') . ' </span>%',
          'separator'   => '<span class="screen-reader-text"> </span>',
        ]);
        ?>
      </div>
    </div>
  </article>
  <!-- !single post -->

<?php else : ?>

  <!-- post-<?php the_ID(); ?> -->
  <article <?php post_class("tj__post post-card wow fadeInUp"); ?> id="post-<?php the_ID(); ?>" data-wow-delay="0.4s">

    <?php if (!empty($gallery_images)) : ?>
      <!-- post gallery -->
      <div class="tj_post-thumb tj-post__gallery swiper swiper-container">
        <div class="swiper-wrapper">
          <?php foreach ($gallery_images as $key => $image) : ?>
            <div class="tj-post-gallery__image swiper-slide">
              <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
            </div>
          <?php endforeach; ?>
        </div>
        <div class="tj-post-gallery__nav">
          <button class="tj-gallery-button__next"><i class="fa-regular fa-arrow-right"></i></button>
          <button class="tj-gallery-button__prev"><i class="fa-regular fa-arrow-left"></i></button>
        </div>
      </div>
    <?php endif; ?>

    <div class="tj-post__content post-content">

      <!-- entry-meta -->
      <?php get_template_part('template-parts/blog/post-meta'); ?>

      <!-- entry title -->
      <?php the_title('<h3 class="tj-post__title entry-title post-content-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>'); ?>

      <!-- post excerpt -->
      <div class="blog-stander__text">
        <?php echo wp_trim_words(get_the_content(), '40', '...'); ?>
      </div>

      <!-- post btn -->
      <?php get_template_part('template-parts/blog/post-btn'); ?>

    </div>
    <div class="tj-clearfix"></div>
  </article><!-- !post-<?php the_ID(); ?> -->

<?php endif; ?>